----------------------------------------------------
-- Export file for user SYSTEM                    --
-- Created by Administrator on 2020/2/4, 17:26:17 --
----------------------------------------------------

set define off
spool QAU.log

prompt
prompt Creating table AQ$_INTERNET_AGENTS
prompt ==================================
prompt
create table SYSTEM.AQ$_INTERNET_AGENTS
(
  agent_name VARCHAR2(30) not null,
  protocol   INTEGER not null,
  spare1     VARCHAR2(128)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_INTERNET_AGENTS
  add primary key (AGENT_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AQ$_INTERNET_AGENT_PRIVS
prompt =======================================
prompt
create table SYSTEM.AQ$_INTERNET_AGENT_PRIVS
(
  agent_name  VARCHAR2(30) not null,
  db_username VARCHAR2(30) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_INTERNET_AGENT_PRIVS
  add constraint UNQ_PAIRS unique (AGENT_NAME, DB_USERNAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_INTERNET_AGENT_PRIVS
  add constraint AGENT_MUST_BE_CREATED foreign key (AGENT_NAME)
  references SYSTEM.AQ$_INTERNET_AGENTS (AGENT_NAME) on delete cascade;

prompt
prompt Creating table AQ$_QUEUES
prompt =========================
prompt
create table SYSTEM.AQ$_QUEUES
(
  oid              RAW(16) not null,
  eventid          NUMBER not null,
  name             VARCHAR2(30) not null,
  table_objno      NUMBER not null,
  usage            NUMBER not null,
  enable_flag      NUMBER not null,
  max_retries      NUMBER,
  retry_delay      NUMBER,
  properties       NUMBER,
  ret_time         NUMBER,
  queue_comment    VARCHAR2(2000),
  subscribers      SYS.AQ$_SUBSCRIBERS,
  memory_threshold NUMBER,
  service_name     VARCHAR2(64),
  network_name     VARCHAR2(256)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_QUEUES
  add constraint AQ$_QUEUES_PRIMARY primary key (OID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_QUEUES
  add constraint AQ$_QUEUES_CHECK unique (NAME, TABLE_OBJNO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AQ$_QUEUE_TABLES
prompt ===============================
prompt
create table SYSTEM.AQ$_QUEUE_TABLES
(
  schema        VARCHAR2(30) not null,
  name          VARCHAR2(30) not null,
  udata_type    NUMBER not null,
  objno         NUMBER not null,
  flags         NUMBER not null,
  sort_cols     NUMBER not null,
  timezone      VARCHAR2(64),
  table_comment VARCHAR2(2000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_QUEUE_TABLES
  add constraint AQ$_QUEUE_TABLES_PRIMARY primary key (OBJNO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AQ$_SCHEDULES
prompt ============================
prompt
create table SYSTEM.AQ$_SCHEDULES
(
  oid         RAW(16) not null,
  destination VARCHAR2(128) not null,
  start_time  DATE,
  duration    VARCHAR2(8),
  next_time   VARCHAR2(128),
  latency     VARCHAR2(8),
  last_time   DATE,
  jobno       NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_SCHEDULES
  add constraint AQ$_SCHEDULES_PRIMARY primary key (OID, DESTINATION)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.AQ$_SCHEDULES
  add constraint AQ$_SCHEDULES_CHECK unique (JOBNO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DEF$_AQCALL
prompt ==========================
prompt
begin
  sys.dbms_aqadm.create_queue_table(
    queue_table => 'SYSTEM.DEF$_AQCALL',
    queue_payload_type => '',
    sort_list => 'ENQ_TIME',
    compatible => '8.0.3',
    primary_instance => 0,
    secondary_instance => 0,
    storage_clause => 'tablespace SYSTEM pctfree 10 pctused 40 initrans 1 maxtrans 255 storage ( initial 64K minextents 1 maxextents unlimited )');
end;
/

prompt
prompt Creating table DEF$_AQERROR
prompt ===========================
prompt
begin
  sys.dbms_aqadm.create_queue_table(
    queue_table => 'SYSTEM.DEF$_AQERROR',
    queue_payload_type => '',
    sort_list => 'ENQ_TIME',
    compatible => '8.0.3',
    primary_instance => 0,
    secondary_instance => 0,
    storage_clause => 'tablespace SYSTEM pctfree 10 pctused 40 initrans 1 maxtrans 255 storage ( initial 64K minextents 1 maxextents unlimited )');
end;
/

prompt
prompt Creating table DEF$_DESTINATION
prompt ===============================
prompt
create table SYSTEM.DEF$_DESTINATION
(
  dblink                     VARCHAR2(128) not null,
  last_delivered             NUMBER default 0 not null,
  last_enq_tid               VARCHAR2(22),
  last_seq                   NUMBER,
  disabled                   CHAR(1),
  job                        NUMBER,
  last_txn_count             NUMBER,
  last_error_number          NUMBER,
  last_error_message         VARCHAR2(2000),
  apply_init                 VARCHAR2(4000),
  catchup                    RAW(16) default '00' not null,
  alternate                  CHAR(1) default 'F',
  total_txn_count            NUMBER default 0,
  total_prop_time_throughput NUMBER default 0,
  total_prop_time_latency    NUMBER default 0,
  to_communication_size      NUMBER default 0,
  from_communication_size    NUMBER default 0,
  flag                       RAW(4) default '00000000',
  spare1                     NUMBER default 0,
  spare2                     NUMBER default 0,
  spare3                     NUMBER default 0,
  spare4                     NUMBER default 0
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_DESTINATION
  is 'Information about propagation to different destinations';
comment on column SYSTEM.DEF$_DESTINATION.dblink
  is 'Destination';
comment on column SYSTEM.DEF$_DESTINATION.last_delivered
  is 'Value of delivery_order of last transaction propagated';
comment on column SYSTEM.DEF$_DESTINATION.last_enq_tid
  is 'Transaction ID of last transaction propagated';
comment on column SYSTEM.DEF$_DESTINATION.last_seq
  is 'Parallel prop seq number of last transaction propagated';
comment on column SYSTEM.DEF$_DESTINATION.disabled
  is 'Is propagation to destination disabled';
comment on column SYSTEM.DEF$_DESTINATION.job
  is 'Number of job that pushes queue';
comment on column SYSTEM.DEF$_DESTINATION.last_txn_count
  is 'Number of transactions pushed during last attempt';
comment on column SYSTEM.DEF$_DESTINATION.last_error_number
  is 'Oracle error number from last push';
comment on column SYSTEM.DEF$_DESTINATION.last_error_message
  is 'Error message from last push';
comment on column SYSTEM.DEF$_DESTINATION.catchup
  is 'Used to break transaction into pieces';
comment on column SYSTEM.DEF$_DESTINATION.alternate
  is 'Used to break transaction into pieces';
comment on column SYSTEM.DEF$_DESTINATION.total_txn_count
  is 'Total number of transactions pushed';
comment on column SYSTEM.DEF$_DESTINATION.total_prop_time_throughput
  is 'Total propagation time in seconds for measuring throughput';
comment on column SYSTEM.DEF$_DESTINATION.total_prop_time_latency
  is 'Total propagation time in seconds for measuring latency';
comment on column SYSTEM.DEF$_DESTINATION.to_communication_size
  is 'Total number of bytes sent to this dblink';
comment on column SYSTEM.DEF$_DESTINATION.from_communication_size
  is 'Total number of bytes received from this dblink';
comment on column SYSTEM.DEF$_DESTINATION.spare1
  is 'Total number of round trips for this dblink';
comment on column SYSTEM.DEF$_DESTINATION.spare2
  is 'Total number of administrative requests';
comment on column SYSTEM.DEF$_DESTINATION.spare3
  is 'Total number of error transactions pushed';
comment on column SYSTEM.DEF$_DESTINATION.spare4
  is 'Total time in seconds spent sleeping during push';
alter table SYSTEM.DEF$_DESTINATION
  add constraint DEF$_DESTINATION_PRIMARY primary key (DBLINK, CATCHUP)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DEF$_CALLDEST
prompt ============================
prompt
create table SYSTEM.DEF$_CALLDEST
(
  enq_tid      VARCHAR2(22) not null,
  step_no      NUMBER not null,
  dblink       VARCHAR2(128) not null,
  schema_name  VARCHAR2(30),
  package_name VARCHAR2(30),
  catchup      RAW(16) default '00'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_CALLDEST
  is 'Information about call destinations for D-type and error transactions';
comment on column SYSTEM.DEF$_CALLDEST.enq_tid
  is 'Transaction ID';
comment on column SYSTEM.DEF$_CALLDEST.step_no
  is 'Unique ID of call within transaction';
comment on column SYSTEM.DEF$_CALLDEST.dblink
  is 'The destination database';
comment on column SYSTEM.DEF$_CALLDEST.schema_name
  is 'The schema of the deferred remote procedure call';
comment on column SYSTEM.DEF$_CALLDEST.package_name
  is 'The package of the deferred remote procedure call';
comment on column SYSTEM.DEF$_CALLDEST.catchup
  is 'Dummy column for foreign key';
create index SYSTEM.DEF$_CALLDEST_N2 on SYSTEM.DEF$_CALLDEST (DBLINK, CATCHUP)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.DEF$_CALLDEST
  add constraint DEF$_CALLDEST_PRIMARY primary key (ENQ_TID, DBLINK, STEP_NO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.DEF$_CALLDEST
  add constraint DEF$_CALL_DESTINATION foreign key (DBLINK, CATCHUP)
  references SYSTEM.DEF$_DESTINATION (DBLINK, CATCHUP);

prompt
prompt Creating table DEF$_DEFAULTDEST
prompt ===============================
prompt
create table SYSTEM.DEF$_DEFAULTDEST
(
  dblink VARCHAR2(128) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_DEFAULTDEST
  is 'Default destinations for deferred remote procedure calls';
comment on column SYSTEM.DEF$_DEFAULTDEST.dblink
  is 'Default destination';
alter table SYSTEM.DEF$_DEFAULTDEST
  add constraint DEF$_DEFAULTDEST_PRIMARY primary key (DBLINK)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DEF$_ERROR
prompt =========================
prompt
create table SYSTEM.DEF$_ERROR
(
  enq_tid        VARCHAR2(22) not null,
  origin_tran_db VARCHAR2(128),
  origin_enq_tid VARCHAR2(22),
  destination    VARCHAR2(128),
  step_no        NUMBER,
  receiver       NUMBER,
  enq_time       DATE,
  error_number   NUMBER,
  error_msg      VARCHAR2(2000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_ERROR
  is 'Information about all deferred transactions that caused an error';
comment on column SYSTEM.DEF$_ERROR.enq_tid
  is 'The ID of the transaction that created the error';
comment on column SYSTEM.DEF$_ERROR.origin_tran_db
  is 'The database originating the deferred transaction';
comment on column SYSTEM.DEF$_ERROR.origin_enq_tid
  is 'The original ID of the transaction';
comment on column SYSTEM.DEF$_ERROR.destination
  is 'Database link used to address destination';
comment on column SYSTEM.DEF$_ERROR.step_no
  is 'Unique ID of call that caused an error';
comment on column SYSTEM.DEF$_ERROR.receiver
  is 'User ID of the original receiver';
comment on column SYSTEM.DEF$_ERROR.enq_time
  is 'Time original transaction enqueued';
comment on column SYSTEM.DEF$_ERROR.error_number
  is 'Oracle error number';
comment on column SYSTEM.DEF$_ERROR.error_msg
  is 'Error message text';
alter table SYSTEM.DEF$_ERROR
  add constraint DEF$_ERROR_PRIMARY primary key (ENQ_TID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DEF$_LOB
prompt =======================
prompt
create table SYSTEM.DEF$_LOB
(
  id        RAW(16) not null,
  enq_tid   VARCHAR2(22),
  blob_col  BLOB,
  clob_col  CLOB,
  nclob_col NCLOB
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_LOB
  is 'Storage for LOB parameters to deferred RPCs';
comment on column SYSTEM.DEF$_LOB.id
  is 'Identifier of LOB parameter';
comment on column SYSTEM.DEF$_LOB.enq_tid
  is 'Transaction identifier for deferred RPC with this LOB parameter';
comment on column SYSTEM.DEF$_LOB.blob_col
  is 'Binary LOB parameter';
comment on column SYSTEM.DEF$_LOB.clob_col
  is 'Character LOB parameter';
comment on column SYSTEM.DEF$_LOB.nclob_col
  is 'National Character LOB parameter';
create index SYSTEM.DEF$_LOB_N1 on SYSTEM.DEF$_LOB (ENQ_TID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.DEF$_LOB
  add constraint DEF$_LOB_PRIMARY primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DEF$_ORIGIN
prompt ==========================
prompt
create table SYSTEM.DEF$_ORIGIN
(
  origin_db     VARCHAR2(128),
  origin_dblink VARCHAR2(128),
  inusr         NUMBER,
  cscn          NUMBER,
  enq_tid       VARCHAR2(22),
  reco_seq_no   NUMBER,
  catchup       RAW(16) default '00'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_ORIGIN
  is 'Information about deferred transactions pushed to this site';
comment on column SYSTEM.DEF$_ORIGIN.origin_db
  is 'Originating database for the deferred transaction';
comment on column SYSTEM.DEF$_ORIGIN.origin_dblink
  is 'Database link from deferred transaction origin to this site';
comment on column SYSTEM.DEF$_ORIGIN.inusr
  is 'Connected user receiving the deferred transaction';
comment on column SYSTEM.DEF$_ORIGIN.cscn
  is 'Prepare SCN assigned at origin site';
comment on column SYSTEM.DEF$_ORIGIN.enq_tid
  is 'Transaction id assigned at origin site';
comment on column SYSTEM.DEF$_ORIGIN.reco_seq_no
  is 'Deferred transaction sequence number for recovery';
comment on column SYSTEM.DEF$_ORIGIN.catchup
  is 'Used to break transaction into pieces';

prompt
prompt Creating table DEF$_PROPAGATOR
prompt ==============================
prompt
create table SYSTEM.DEF$_PROPAGATOR
(
  userid   NUMBER not null,
  username VARCHAR2(30) not null,
  created  DATE default SYSDATE not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_PROPAGATOR
  is 'The propagator for deferred remote procedure calls';
comment on column SYSTEM.DEF$_PROPAGATOR.userid
  is 'User ID of the propagator';
comment on column SYSTEM.DEF$_PROPAGATOR.username
  is 'User name of the propagator';
comment on column SYSTEM.DEF$_PROPAGATOR.created
  is 'The time when the propagator is registered';
alter table SYSTEM.DEF$_PROPAGATOR
  add constraint DEF$_PROPAGATOR_PRIMARY primary key (USERID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DEF$_PUSHED_TRANSACTIONS
prompt =======================================
prompt
create table SYSTEM.DEF$_PUSHED_TRANSACTIONS
(
  source_site_id NUMBER not null,
  last_tran_id   NUMBER default 0,
  disabled       VARCHAR2(1) default 'F',
  source_site    VARCHAR2(128)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.DEF$_PUSHED_TRANSACTIONS
  is 'Information about deferred transactions pushed to this site by RepAPI clients';
comment on column SYSTEM.DEF$_PUSHED_TRANSACTIONS.source_site_id
  is 'Originating database identifier for the deferred transaction';
comment on column SYSTEM.DEF$_PUSHED_TRANSACTIONS.last_tran_id
  is 'Last committed transaction';
comment on column SYSTEM.DEF$_PUSHED_TRANSACTIONS.disabled
  is 'Disable propagation';
comment on column SYSTEM.DEF$_PUSHED_TRANSACTIONS.source_site
  is 'Obsolete - do not use';
alter table SYSTEM.DEF$_PUSHED_TRANSACTIONS
  add constraint DEF$_PUSHED_TRAN_PRIMARY primary key (SOURCE_SITE_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.DEF$_PUSHED_TRANSACTIONS
  add check (disabled IN ('T', 'F'));

prompt
prompt Creating table DEF$_TEMP$LOB
prompt ============================
prompt
create table SYSTEM.DEF$_TEMP$LOB
(
  temp$blob  BLOB,
  temp$clob  CLOB,
  temp$nclob NCLOB
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  )
nologging;
comment on table SYSTEM.DEF$_TEMP$LOB
  is 'Storage for LOB parameters to RPCs';
comment on column SYSTEM.DEF$_TEMP$LOB.temp$blob
  is 'Binary LOB (deferred) RPC parameter';
comment on column SYSTEM.DEF$_TEMP$LOB.temp$clob
  is 'Character LOB (deferred) RPC parameter';
comment on column SYSTEM.DEF$_TEMP$LOB.temp$nclob
  is 'National Character LOB (deferred) RPC parameter';

prompt
prompt Creating table HELP
prompt ===================
prompt
create table SYSTEM.HELP
(
  topic VARCHAR2(50) not null,
  seq   NUMBER not null,
  info  VARCHAR2(80)
)
tablespace SYSTEM
  pctfree 0
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 48K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.HELP
  add constraint HELP_TOPIC_SEQ primary key (TOPIC, SEQ)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNRC_DBNAME_UID_MAP
prompt =====================================
prompt
create table SYSTEM.LOGMNRC_DBNAME_UID_MAP
(
  global_name VARCHAR2(128) not null,
  logmnr_uid  NUMBER,
  flags       NUMBER
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNRC_DBNAME_UID_MAP
  add constraint LOGMNRC_DBNAME_UID_MAP_PK primary key (GLOBAL_NAME)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNRC_GSII
prompt ===========================
prompt
create table SYSTEM.LOGMNRC_GSII
(
  logmnr_uid    NUMBER not null,
  obj#          NUMBER not null,
  bo#           NUMBER not null,
  indtype#      NUMBER not null,
  drop_scn      NUMBER,
  logmnr_spare1 NUMBER,
  logmnr_spare2 NUMBER,
  logmnr_spare3 VARCHAR2(1000),
  logmnr_spare4 DATE
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
alter table SYSTEM.LOGMNRC_GSII
  add constraint LOGMNRC_GSII_PK primary key (LOGMNR_UID, OBJ#)
  using index 
  local;

prompt
prompt Creating table LOGMNRC_GTCS
prompt ===========================
prompt
create table SYSTEM.LOGMNRC_GTCS
(
  logmnr_uid                  NUMBER not null,
  obj#                        NUMBER not null,
  objv#                       NUMBER not null,
  segcol#                     NUMBER not null,
  intcol#                     NUMBER not null,
  colname                     VARCHAR2(30) not null,
  type#                       NUMBER not null,
  length                      NUMBER,
  precision                   NUMBER,
  scale                       NUMBER,
  interval_leading_precision  NUMBER,
  interval_trailing_precision NUMBER,
  property                    NUMBER,
  toid                        RAW(16),
  charsetid                   NUMBER,
  charsetform                 NUMBER,
  typename                    VARCHAR2(30),
  fqcolname                   VARCHAR2(4000),
  numintcols                  NUMBER,
  numattrs                    NUMBER,
  adtorder                    NUMBER,
  logmnr_spare1               NUMBER,
  logmnr_spare2               NUMBER,
  logmnr_spare3               VARCHAR2(1000),
  logmnr_spare4               DATE,
  logmnr_spare5               NUMBER,
  logmnr_spare6               NUMBER,
  logmnr_spare7               NUMBER,
  logmnr_spare8               NUMBER,
  logmnr_spare9               NUMBER
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
alter table SYSTEM.LOGMNRC_GTCS
  add constraint LOGMNRC_GTCS_PK primary key (LOGMNR_UID, OBJ#, OBJV#, INTCOL#)
  using index 
  local;

prompt
prompt Creating table LOGMNRC_GTLO
prompt ===========================
prompt
create table SYSTEM.LOGMNRC_GTLO
(
  logmnr_uid    NUMBER not null,
  keyobj#       NUMBER not null,
  lvlcnt        NUMBER not null,
  baseobj#      NUMBER not null,
  baseobjv#     NUMBER not null,
  lvl1obj#      NUMBER,
  lvl2obj#      NUMBER,
  lvl0type#     NUMBER not null,
  lvl1type#     NUMBER,
  lvl2type#     NUMBER,
  owner#        NUMBER,
  ownername     VARCHAR2(30) not null,
  lvl0name      VARCHAR2(30) not null,
  lvl1name      VARCHAR2(30),
  lvl2name      VARCHAR2(30),
  intcols       NUMBER not null,
  cols          NUMBER,
  kernelcols    NUMBER,
  tab_flags     NUMBER,
  trigflag      NUMBER,
  assoc#        NUMBER,
  obj_flags     NUMBER,
  ts#           NUMBER,
  tsname        VARCHAR2(30),
  property      NUMBER,
  start_scn     NUMBER not null,
  drop_scn      NUMBER,
  xidusn        NUMBER,
  xidslt        NUMBER,
  xidsqn        NUMBER,
  flags         NUMBER,
  logmnr_spare1 NUMBER,
  logmnr_spare2 NUMBER,
  logmnr_spare3 VARCHAR2(1000),
  logmnr_spare4 DATE,
  logmnr_spare5 NUMBER,
  logmnr_spare6 NUMBER,
  logmnr_spare7 NUMBER,
  logmnr_spare8 NUMBER,
  logmnr_spare9 NUMBER
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNRC_I2GTLO on SYSTEM.LOGMNRC_GTLO (LOGMNR_UID, BASEOBJ#, BASEOBJV#)
  local;
create index SYSTEM.LOGMNRC_I3GTLO on SYSTEM.LOGMNRC_GTLO (LOGMNR_UID, DROP_SCN)
  local;
alter table SYSTEM.LOGMNRC_GTLO
  add constraint LOGMNRC_GTLO_PK primary key (LOGMNR_UID, KEYOBJ#, BASEOBJV#)
  using index 
  local;

prompt
prompt Creating table LOGMNRP_CTAS_PART_MAP
prompt ====================================
prompt
create table SYSTEM.LOGMNRP_CTAS_PART_MAP
(
  logmnr_uid NUMBER not null,
  baseobj#   NUMBER not null,
  baseobjv#  NUMBER not null,
  keyobj#    NUMBER not null,
  part#      NUMBER not null,
  spare1     NUMBER,
  spare2     NUMBER,
  spare3     VARCHAR2(1000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.LOGMNRP_CTAS_PART_MAP_I on SYSTEM.LOGMNRP_CTAS_PART_MAP (LOGMNR_UID, BASEOBJ#, BASEOBJV#, PART#)
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNRP_CTAS_PART_MAP
  add constraint LOGMNRP_CTAS_PART_MAP_PK primary key (LOGMNR_UID, BASEOBJV#, KEYOBJ#)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNRT_MDDL$
prompt ============================
prompt
create global temporary table SYSTEM.LOGMNRT_MDDL$
(
  source_obj#  NUMBER not null,
  source_rowid ROWID not null,
  dest_rowid   ROWID not null
)
on commit delete rows;
alter table SYSTEM.LOGMNRT_MDDL$
  add constraint LOGMNRT_MDDL$_PK primary key (SOURCE_OBJ#, SOURCE_ROWID);

prompt
prompt Creating table LOGMNR_AGE_SPILL$
prompt ================================
prompt
create table SYSTEM.LOGMNR_AGE_SPILL$
(
  session#   NUMBER not null,
  xidusn     NUMBER not null,
  xidslt     NUMBER not null,
  xidsqn     NUMBER not null,
  chunk      INTEGER not null,
  sequence#  NUMBER not null,
  offset     NUMBER,
  spill_data BLOB,
  spare1     NUMBER,
  spare2     NUMBER
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_AGE_SPILL$
  add constraint LOGMNR_AGE_SPILL$_PK primary key (SESSION#, XIDUSN, XIDSLT, XIDSQN, CHUNK, SEQUENCE#)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_ATTRCOL$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_ATTRCOL$
(
  intcol#    NUMBER,
  name       VARCHAR2(4000),
  obj#       NUMBER not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1ATTRCOL$ on SYSTEM.LOGMNR_ATTRCOL$ (LOGMNR_UID, OBJ#, INTCOL#)
  local;
alter table SYSTEM.LOGMNR_ATTRCOL$
  add constraint LOGMNR_ATTRCOL$_PK primary key (LOGMNR_UID, OBJ#, INTCOL#)
  disable;

prompt
prompt Creating table LOGMNR_ATTRIBUTE$
prompt ================================
prompt
create table SYSTEM.LOGMNR_ATTRIBUTE$
(
  version#      NUMBER(22),
  name          VARCHAR2(30),
  attribute#    NUMBER(22),
  attr_toid     RAW(16),
  attr_version# NUMBER(22),
  properties    NUMBER(22),
  toid          RAW(16) not null,
  logmnr_uid    NUMBER(22),
  objv#         NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
alter table SYSTEM.LOGMNR_ATTRIBUTE$
  add constraint LOGMNR_ATTRIBUTE$_PK primary key (LOGMNR_UID, TOID, VERSION#, ATTRIBUTE#)
  disable;

prompt
prompt Creating table LOGMNR_CCOL$
prompt ===========================
prompt
create table SYSTEM.LOGMNR_CCOL$
(
  con#       NUMBER,
  obj#       NUMBER,
  col#       NUMBER,
  pos#       NUMBER,
  intcol#    NUMBER not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1CCOL$ on SYSTEM.LOGMNR_CCOL$ (LOGMNR_UID, CON#, INTCOL#)
  local;
alter table SYSTEM.LOGMNR_CCOL$
  add constraint LOGMNR_CCOL$_PK primary key (LOGMNR_UID, CON#, INTCOL#)
  disable;

prompt
prompt Creating table LOGMNR_CDEF$
prompt ===========================
prompt
create table SYSTEM.LOGMNR_CDEF$
(
  con#       NUMBER,
  cols       NUMBER,
  type#      NUMBER,
  robj#      NUMBER,
  rcon#      NUMBER,
  enabled    NUMBER,
  defer      NUMBER,
  obj#       NUMBER not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1CDEF$ on SYSTEM.LOGMNR_CDEF$ (LOGMNR_UID, CON#)
  local;
alter table SYSTEM.LOGMNR_CDEF$
  add constraint LOGMNR_CDEF$_PK primary key (LOGMNR_UID, CON#)
  disable;

prompt
prompt Creating table LOGMNR_COL$
prompt ==========================
prompt
create table SYSTEM.LOGMNR_COL$
(
  col#        NUMBER(22),
  segcol#     NUMBER(22),
  name        VARCHAR2(30),
  type#       NUMBER(22),
  length      NUMBER(22),
  precision#  NUMBER(22),
  scale       NUMBER(22),
  null$       NUMBER(22),
  intcol#     NUMBER(22),
  property    NUMBER(22),
  charsetid   NUMBER(22),
  charsetform NUMBER(22),
  spare1      NUMBER(22),
  spare2      NUMBER(22),
  obj#        NUMBER(22) not null,
  logmnr_uid  NUMBER(22),
  objv#       NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1COL$ on SYSTEM.LOGMNR_COL$ (LOGMNR_UID, OBJ#, INTCOL#)
  local;
create index SYSTEM.LOGMNR_I2COL$ on SYSTEM.LOGMNR_COL$ (LOGMNR_UID, OBJ#, NAME)
  local;
alter table SYSTEM.LOGMNR_COL$
  add constraint LOGMNR_COL$_PK primary key (LOGMNR_UID, OBJ#, INTCOL#)
  disable;

prompt
prompt Creating table LOGMNR_COLTYPE$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_COLTYPE$
(
  col#       NUMBER(22),
  intcol#    NUMBER(22),
  toid       RAW(16),
  version#   NUMBER(22),
  intcols    NUMBER(22),
  typidcol#  NUMBER(22),
  obj#       NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1COLTYPE$ on SYSTEM.LOGMNR_COLTYPE$ (LOGMNR_UID, OBJ#, INTCOL#)
  local;
alter table SYSTEM.LOGMNR_COLTYPE$
  add constraint LOGMNR_COLTYPE$_PK primary key (LOGMNR_UID, OBJ#, INTCOL#)
  disable;

prompt
prompt Creating table LOGMNR_DICTIONARY$
prompt =================================
prompt
create table SYSTEM.LOGMNR_DICTIONARY$
(
  db_name              VARCHAR2(9),
  db_id                NUMBER(20),
  db_created           VARCHAR2(20),
  db_dict_created      VARCHAR2(20),
  db_dict_scn          NUMBER(22),
  db_thread_map        RAW(8),
  db_txn_scnbas        NUMBER(22),
  db_txn_scnwrp        NUMBER(22),
  db_resetlogs_change# NUMBER(22),
  db_resetlogs_time    VARCHAR2(20),
  db_version_time      VARCHAR2(20),
  db_redo_type_id      VARCHAR2(8),
  db_redo_release      VARCHAR2(60),
  db_character_set     VARCHAR2(30),
  db_version           VARCHAR2(64),
  db_status            VARCHAR2(64),
  db_global_name       VARCHAR2(128),
  db_dict_maxobjects   NUMBER(22),
  db_dict_objectcount  NUMBER(22) not null,
  logmnr_uid           NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
alter table SYSTEM.LOGMNR_DICTIONARY$
  add constraint LOGMNR_DICTIONARY$_PK primary key (LOGMNR_UID)
  disable;

prompt
prompt Creating table LOGMNR_DICTSTATE$
prompt ================================
prompt
create table SYSTEM.LOGMNR_DICTSTATE$
(
  logmnr_uid   NUMBER(22),
  start_scnbas NUMBER,
  start_scnwrp NUMBER,
  end_scnbas   NUMBER,
  end_scnwrp   NUMBER,
  redo_thread  NUMBER,
  rbasqn       NUMBER,
  rbablk       NUMBER,
  rbabyte      NUMBER
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
alter table SYSTEM.LOGMNR_DICTSTATE$
  add constraint LOGMNR_DICTSTATE$_PK primary key (LOGMNR_UID)
  disable;

prompt
prompt Creating table LOGMNR_ERROR$
prompt ============================
prompt
create table SYSTEM.LOGMNR_ERROR$
(
  session#      NUMBER,
  time_of_error DATE,
  code          NUMBER,
  message       VARCHAR2(4000),
  spare1        NUMBER,
  spare2        NUMBER,
  spare3        NUMBER,
  spare4        VARCHAR2(4000),
  spare5        VARCHAR2(4000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_FILTER$
prompt =============================
prompt
create table SYSTEM.LOGMNR_FILTER$
(
  session#    NUMBER,
  filter_type VARCHAR2(30),
  attr1       NUMBER,
  attr2       NUMBER,
  attr3       NUMBER,
  attr4       NUMBER,
  attr5       NUMBER,
  attr6       NUMBER,
  filter_scn  NUMBER,
  spare1      NUMBER,
  spare2      NUMBER,
  spare3      DATE
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_HEADER1$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_HEADER1$
(
  logmnr_uid NUMBER(22)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_HEADER2$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_HEADER2$
(
  objv# NUMBER(22)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_ICOL$
prompt ===========================
prompt
create table SYSTEM.LOGMNR_ICOL$
(
  obj#       NUMBER,
  bo#        NUMBER,
  col#       NUMBER,
  pos#       NUMBER,
  segcol#    NUMBER,
  intcol#    NUMBER not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1ICOL$ on SYSTEM.LOGMNR_ICOL$ (LOGMNR_UID, OBJ#, INTCOL#)
  local;
alter table SYSTEM.LOGMNR_ICOL$
  add constraint LOGMNR_ICOL$_PK primary key (LOGMNR_UID, OBJ#, INTCOL#)
  disable;

prompt
prompt Creating table LOGMNR_IND$
prompt ==========================
prompt
create table SYSTEM.LOGMNR_IND$
(
  bo#        NUMBER(22),
  cols       NUMBER(22),
  type#      NUMBER(22),
  flags      NUMBER,
  property   NUMBER,
  obj#       NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1IND$ on SYSTEM.LOGMNR_IND$ (LOGMNR_UID, OBJ#)
  local;
create index SYSTEM.LOGMNR_I2IND$ on SYSTEM.LOGMNR_IND$ (LOGMNR_UID, BO#)
  local;
alter table SYSTEM.LOGMNR_IND$
  add constraint LOGMNR_IND$_PK primary key (LOGMNR_UID, OBJ#)
  disable;

prompt
prompt Creating table LOGMNR_INDCOMPART$
prompt =================================
prompt
create table SYSTEM.LOGMNR_INDCOMPART$
(
  obj#       NUMBER,
  dataobj#   NUMBER,
  bo#        NUMBER,
  part#      NUMBER not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1INDCOMPART$ on SYSTEM.LOGMNR_INDCOMPART$ (LOGMNR_UID, OBJ#)
  local;
alter table SYSTEM.LOGMNR_INDCOMPART$
  add constraint LOGMNR_INDCOMPART$_PK primary key (LOGMNR_UID, OBJ#)
  disable;

prompt
prompt Creating table LOGMNR_INDPART$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_INDPART$
(
  obj#       NUMBER,
  bo#        NUMBER,
  part#      NUMBER,
  ts#        NUMBER not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1INDPART$ on SYSTEM.LOGMNR_INDPART$ (LOGMNR_UID, OBJ#, BO#)
  local;
create index SYSTEM.LOGMNR_I2INDPART$ on SYSTEM.LOGMNR_INDPART$ (LOGMNR_UID, BO#)
  local;
alter table SYSTEM.LOGMNR_INDPART$
  add constraint LOGMNR_INDPART$_PK primary key (LOGMNR_UID, OBJ#, BO#)
  disable;

prompt
prompt Creating table LOGMNR_INDSUBPART$
prompt =================================
prompt
create table SYSTEM.LOGMNR_INDSUBPART$
(
  obj#       NUMBER(22),
  dataobj#   NUMBER(22),
  pobj#      NUMBER(22),
  subpart#   NUMBER(22),
  ts#        NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1INDSUBPART$ on SYSTEM.LOGMNR_INDSUBPART$ (LOGMNR_UID, OBJ#, POBJ#)
  local;
alter table SYSTEM.LOGMNR_INDSUBPART$
  add constraint LOGMNR_INDSUBPART$_PK primary key (LOGMNR_UID, OBJ#, POBJ#)
  disable;

prompt
prompt Creating table LOGMNR_LOB$
prompt ==========================
prompt
create table SYSTEM.LOGMNR_LOB$
(
  obj#       NUMBER,
  intcol#    NUMBER,
  col#       NUMBER,
  lobj#      NUMBER,
  chunk      NUMBER not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1LOB$ on SYSTEM.LOGMNR_LOB$ (LOGMNR_UID, OBJ#, INTCOL#)
  local;
alter table SYSTEM.LOGMNR_LOB$
  add constraint LOGMNR_LOB$_PK primary key (LOGMNR_UID, OBJ#, INTCOL#)
  disable;

prompt
prompt Creating table LOGMNR_LOBFRAG$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_LOBFRAG$
(
  fragobj#    NUMBER,
  parentobj#  NUMBER,
  tabfragobj# NUMBER,
  indfragobj# NUMBER,
  frag#       NUMBER not null,
  logmnr_uid  NUMBER(22),
  objv#       NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1LOBFRAG$ on SYSTEM.LOGMNR_LOBFRAG$ (LOGMNR_UID, FRAGOBJ#)
  local;
alter table SYSTEM.LOGMNR_LOBFRAG$
  add constraint LOGMNR_LOBFRAG$_PK primary key (LOGMNR_UID, FRAGOBJ#)
  disable;

prompt
prompt Creating table LOGMNR_LOG$
prompt ==========================
prompt
create table SYSTEM.LOGMNR_LOG$
(
  session#               NUMBER not null,
  thread#                NUMBER not null,
  sequence#              NUMBER not null,
  first_change#          NUMBER not null,
  next_change#           NUMBER,
  first_time             DATE,
  next_time              DATE,
  file_name              VARCHAR2(513),
  status                 NUMBER,
  info                   VARCHAR2(32),
  timestamp              DATE,
  dict_begin             VARCHAR2(3),
  dict_end               VARCHAR2(3),
  status_info            VARCHAR2(32),
  db_id                  NUMBER not null,
  resetlogs_change#      NUMBER not null,
  reset_timestamp        NUMBER not null,
  prev_resetlogs_change# NUMBER,
  prev_reset_timestamp   NUMBER,
  blocks                 NUMBER,
  block_size             NUMBER,
  flags                  NUMBER,
  contents               NUMBER,
  spare1                 NUMBER,
  spare2                 NUMBER,
  spare3                 NUMBER,
  spare4                 NUMBER,
  spare5                 NUMBER
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.LOGMNR_LOG$_FIRST_CHANGE# on SYSTEM.LOGMNR_LOG$ (FIRST_CHANGE#)
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.LOGMNR_LOG$_FLAGS on SYSTEM.LOGMNR_LOG$ (FLAGS)
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_LOG$
  add constraint LOGMNR_LOG$_PK primary key (SESSION#, THREAD#, SEQUENCE#, FIRST_CHANGE#, DB_ID, RESETLOGS_CHANGE#, RESET_TIMESTAMP)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_OBJ$
prompt ==========================
prompt
create table SYSTEM.LOGMNR_OBJ$
(
  objv#        NUMBER(22),
  owner#       NUMBER(22),
  name         VARCHAR2(30),
  namespace    NUMBER(22),
  subname      VARCHAR2(30),
  type#        NUMBER(22),
  oid$         RAW(16),
  remoteowner  VARCHAR2(30),
  linkname     VARCHAR2(128),
  flags        NUMBER(22),
  spare3       NUMBER(22),
  stime        DATE,
  obj#         NUMBER(22) not null,
  logmnr_uid   NUMBER(22),
  start_scnbas NUMBER,
  start_scnwrp NUMBER
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1OBJ$ on SYSTEM.LOGMNR_OBJ$ (LOGMNR_UID, OBJ#)
  local;
alter table SYSTEM.LOGMNR_OBJ$
  add constraint LOGMNR_OBJ$_PK primary key (LOGMNR_UID, OBJ#)
  disable;

prompt
prompt Creating table LOGMNR_PARAMETER$
prompt ================================
prompt
create table SYSTEM.LOGMNR_PARAMETER$
(
  session# NUMBER not null,
  name     VARCHAR2(30) not null,
  value    VARCHAR2(2000),
  type     NUMBER,
  scn      NUMBER,
  spare1   NUMBER,
  spare2   NUMBER,
  spare3   VARCHAR2(2000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.LOGMNR_PARAMETER_INDX on SYSTEM.LOGMNR_PARAMETER$ (SESSION#, NAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_PROCESSED_LOG$
prompt ====================================
prompt
create table SYSTEM.LOGMNR_PROCESSED_LOG$
(
  session#      NUMBER not null,
  thread#       NUMBER not null,
  sequence#     NUMBER,
  first_change# NUMBER,
  next_change#  NUMBER,
  first_time    DATE,
  next_time     DATE,
  file_name     VARCHAR2(513),
  status        NUMBER,
  info          VARCHAR2(32),
  timestamp     DATE
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_PROCESSED_LOG$
  add constraint LOGMNR_PROCESSED_LOG$_PK primary key (SESSION#, THREAD#)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_RESTART_CKPT$
prompt ===================================
prompt
create table SYSTEM.LOGMNR_RESTART_CKPT$
(
  session#    NUMBER not null,
  valid       NUMBER,
  ckpt_scn    NUMBER not null,
  xidusn      NUMBER not null,
  xidslt      NUMBER not null,
  xidsqn      NUMBER not null,
  session_num NUMBER not null,
  serial_num  NUMBER not null,
  ckpt_info   BLOB,
  flag        NUMBER,
  offset      NUMBER,
  client_data BLOB,
  spare1      NUMBER,
  spare2      NUMBER
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_RESTART_CKPT$
  add constraint LOGMNR_RESTART_CKPT$_PK primary key (SESSION#, CKPT_SCN, XIDUSN, XIDSLT, XIDSQN, SESSION_NUM, SERIAL_NUM)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_RESTART_CKPT_TXINFO$
prompt ==========================================
prompt
create table SYSTEM.LOGMNR_RESTART_CKPT_TXINFO$
(
  session#      NUMBER not null,
  xidusn        NUMBER not null,
  xidslt        NUMBER not null,
  xidsqn        NUMBER not null,
  session_num   NUMBER not null,
  serial_num    NUMBER not null,
  flag          NUMBER,
  start_scn     NUMBER,
  effective_scn NUMBER not null,
  offset        NUMBER,
  tx_data       BLOB
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_RESTART_CKPT_TXINFO$
  add constraint LOGMNR_RESTART_CKPT_TXINFO$_PK primary key (SESSION#, XIDUSN, XIDSLT, XIDSQN, SESSION_NUM, SERIAL_NUM, EFFECTIVE_SCN)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_SESSION$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_SESSION$
(
  session#             NUMBER not null,
  client#              NUMBER,
  session_name         VARCHAR2(128) not null,
  db_id                NUMBER,
  resetlogs_change#    NUMBER,
  session_attr         NUMBER,
  session_attr_verbose VARCHAR2(400),
  start_scn            NUMBER,
  end_scn              NUMBER,
  spill_scn            NUMBER,
  spill_time           DATE,
  oldest_scn           NUMBER,
  resume_scn           NUMBER,
  global_db_name       VARCHAR2(128),
  reset_timestamp      NUMBER,
  branch_scn           NUMBER,
  version              VARCHAR2(64),
  spare1               NUMBER,
  spare2               NUMBER,
  spare3               NUMBER,
  spare4               NUMBER,
  spare5               NUMBER,
  spare6               DATE,
  spare7               VARCHAR2(1000),
  spare8               VARCHAR2(1000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_SESSION$
  add constraint LOGMNR_SESSION_PK primary key (SESSION#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_SESSION$
  add constraint LOGMNR_SESSION_UK1 unique (SESSION_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_SESSION_EVOLVE$
prompt =====================================
prompt
create table SYSTEM.LOGMNR_SESSION_EVOLVE$
(
  branch_level         NUMBER,
  session#             NUMBER not null,
  db_id                NUMBER not null,
  reset_scn            NUMBER not null,
  reset_timestamp      NUMBER not null,
  prev_reset_scn       NUMBER,
  prev_reset_timestamp NUMBER,
  status               NUMBER,
  spare1               NUMBER,
  spare2               NUMBER,
  spare3               NUMBER,
  spare4               DATE
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_SESSION_EVOLVE$
  add constraint LOGMNR_SESSION_EVOLVE$_PK primary key (SESSION#, DB_ID, RESET_SCN, RESET_TIMESTAMP)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_SPILL$
prompt ============================
prompt
create table SYSTEM.LOGMNR_SPILL$
(
  session#   NUMBER not null,
  xidusn     NUMBER not null,
  xidslt     NUMBER not null,
  xidsqn     NUMBER not null,
  chunk      INTEGER not null,
  sequence#  NUMBER not null,
  offset     NUMBER,
  spill_data BLOB,
  spare1     NUMBER,
  spare2     NUMBER
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_SPILL$
  add constraint LOGMNR_SPILL$_PK primary key (SESSION#, XIDUSN, XIDSLT, XIDSQN, CHUNK, SEQUENCE#)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_TAB$
prompt ==========================
prompt
create table SYSTEM.LOGMNR_TAB$
(
  ts#        NUMBER(22),
  cols       NUMBER(22),
  property   NUMBER(22),
  intcols    NUMBER(22),
  kernelcols NUMBER(22),
  bobj#      NUMBER(22),
  trigflag   NUMBER(22),
  flags      NUMBER(22),
  obj#       NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1TAB$ on SYSTEM.LOGMNR_TAB$ (LOGMNR_UID, OBJ#)
  local;
create index SYSTEM.LOGMNR_I2TAB$ on SYSTEM.LOGMNR_TAB$ (LOGMNR_UID, BOBJ#)
  local;
alter table SYSTEM.LOGMNR_TAB$
  add constraint LOGMNR_TAB$_PK primary key (LOGMNR_UID, OBJ#)
  disable;

prompt
prompt Creating table LOGMNR_TABCOMPART$
prompt =================================
prompt
create table SYSTEM.LOGMNR_TABCOMPART$
(
  obj#       NUMBER(22),
  bo#        NUMBER(22),
  part#      NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1TABCOMPART$ on SYSTEM.LOGMNR_TABCOMPART$ (LOGMNR_UID, OBJ#)
  local;
create index SYSTEM.LOGMNR_I2TABCOMPART$ on SYSTEM.LOGMNR_TABCOMPART$ (LOGMNR_UID, BO#)
  local;
alter table SYSTEM.LOGMNR_TABCOMPART$
  add constraint LOGMNR_TABCOMPART$_PK primary key (LOGMNR_UID, OBJ#)
  disable;

prompt
prompt Creating table LOGMNR_TABPART$
prompt ==============================
prompt
create table SYSTEM.LOGMNR_TABPART$
(
  obj#       NUMBER(22),
  ts#        NUMBER(22),
  part#      NUMBER,
  bo#        NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1TABPART$ on SYSTEM.LOGMNR_TABPART$ (LOGMNR_UID, OBJ#, BO#)
  local;
create index SYSTEM.LOGMNR_I2TABPART$ on SYSTEM.LOGMNR_TABPART$ (LOGMNR_UID, BO#)
  local;
alter table SYSTEM.LOGMNR_TABPART$
  add constraint LOGMNR_TABPART$_PK primary key (LOGMNR_UID, OBJ#, BO#)
  disable;

prompt
prompt Creating table LOGMNR_TABSUBPART$
prompt =================================
prompt
create table SYSTEM.LOGMNR_TABSUBPART$
(
  obj#       NUMBER(22),
  dataobj#   NUMBER(22),
  pobj#      NUMBER(22),
  subpart#   NUMBER(22),
  ts#        NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1TABSUBPART$ on SYSTEM.LOGMNR_TABSUBPART$ (LOGMNR_UID, OBJ#, POBJ#)
  local;
create index SYSTEM.LOGMNR_I2TABSUBPART$ on SYSTEM.LOGMNR_TABSUBPART$ (LOGMNR_UID, POBJ#)
  local;
alter table SYSTEM.LOGMNR_TABSUBPART$
  add constraint LOGMNR_TABSUBPART$_PK primary key (LOGMNR_UID, OBJ#, POBJ#)
  disable;

prompt
prompt Creating table LOGMNR_TS$
prompt =========================
prompt
create table SYSTEM.LOGMNR_TS$
(
  ts#        NUMBER(22),
  name       VARCHAR2(30),
  owner#     NUMBER(22),
  blocksize  NUMBER(22) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1TS$ on SYSTEM.LOGMNR_TS$ (LOGMNR_UID, TS#)
  local;
alter table SYSTEM.LOGMNR_TS$
  add constraint LOGMNR_TS$_PK primary key (LOGMNR_UID, TS#)
  disable;

prompt
prompt Creating table LOGMNR_TYPE$
prompt ===========================
prompt
create table SYSTEM.LOGMNR_TYPE$
(
  version#   NUMBER(22),
  tvoid      RAW(16),
  properties NUMBER(22),
  attributes NUMBER(22),
  toid       RAW(16) not null,
  logmnr_uid NUMBER(22),
  objv#      NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1TYPE$ on SYSTEM.LOGMNR_TYPE$ (LOGMNR_UID, TOID, VERSION#)
  local;
alter table SYSTEM.LOGMNR_TYPE$
  add constraint LOGMNR_TYPE$_PK primary key (LOGMNR_UID, TOID, VERSION#)
  disable;

prompt
prompt Creating table LOGMNR_UID$
prompt ==========================
prompt
create table SYSTEM.LOGMNR_UID$
(
  logmnr_uid NUMBER(22),
  session#   NUMBER not null
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.LOGMNR_UID$
  add constraint LOGMNR_UID$_PK primary key (SESSION#)
  using index 
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGMNR_USER$
prompt ===========================
prompt
create table SYSTEM.LOGMNR_USER$
(
  user#      NUMBER(22),
  name       VARCHAR2(30) not null,
  logmnr_uid NUMBER(22)
)
partition by range (LOGMNR_UID)
(
  partition P_LESSTHAN100 values less than (100)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);
create index SYSTEM.LOGMNR_I1USER$ on SYSTEM.LOGMNR_USER$ (LOGMNR_UID, USER#)
  local;
alter table SYSTEM.LOGMNR_USER$
  add constraint LOGMNR_USER$_PK primary key (LOGMNR_UID, USER#)
  disable;

prompt
prompt Creating table LOGSTDBY$APPLY_MILESTONE
prompt =======================================
prompt
create table SYSTEM.LOGSTDBY$APPLY_MILESTONE
(
  session_id     NUMBER not null,
  commit_scn     NUMBER not null,
  commit_time    DATE,
  synch_scn      NUMBER not null,
  epoch          NUMBER not null,
  processed_scn  NUMBER not null,
  processed_time DATE,
  fetchlwm_scn   NUMBER default (0) not null,
  spare1         NUMBER,
  spare2         NUMBER,
  spare3         VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$APPLY_PROGRESS
prompt ======================================
prompt
create table SYSTEM.LOGSTDBY$APPLY_PROGRESS
(
  xidusn      NUMBER,
  xidslt      NUMBER,
  xidsqn      NUMBER,
  commit_scn  NUMBER,
  commit_time DATE,
  spare1      NUMBER,
  spare2      NUMBER,
  spare3      VARCHAR2(2000)
)
partition by range (COMMIT_SCN)
(
  partition P0 values less than (0)
    tablespace SYSAUX
    pctfree 10
    initrans 1
    maxtrans 255
    storage
    (
      initial 64K
      minextents 1
      maxextents unlimited
    )
);

prompt
prompt Creating table LOGSTDBY$EVENTS
prompt ==============================
prompt
create table SYSTEM.LOGSTDBY$EVENTS
(
  event_time  TIMESTAMP(6),
  current_scn NUMBER,
  commit_scn  NUMBER,
  xidusn      NUMBER,
  xidslt      NUMBER,
  xidsqn      NUMBER,
  errval      NUMBER,
  event       VARCHAR2(2000),
  full_event  CLOB,
  error       VARCHAR2(2000),
  spare1      NUMBER,
  spare2      NUMBER,
  spare3      VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.LOGSTDBY$EVENTS_IND on SYSTEM.LOGSTDBY$EVENTS (EVENT_TIME)
  tablespace SYSAUX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$HISTORY
prompt ===============================
prompt
create table SYSTEM.LOGSTDBY$HISTORY
(
  stream_sequence# NUMBER,
  lmnr_sid         NUMBER,
  dbid             NUMBER,
  first_change#    NUMBER,
  last_change#     NUMBER,
  source           NUMBER,
  status           NUMBER,
  first_time       DATE,
  last_time        DATE,
  dgname           VARCHAR2(255),
  spare1           NUMBER,
  spare2           NUMBER,
  spare3           VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$PARAMETERS
prompt ==================================
prompt
create table SYSTEM.LOGSTDBY$PARAMETERS
(
  name   VARCHAR2(30),
  value  VARCHAR2(2000),
  type   NUMBER,
  scn    NUMBER,
  spare1 NUMBER,
  spare2 NUMBER,
  spare3 VARCHAR2(2000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$PLSQL
prompt =============================
prompt
create table SYSTEM.LOGSTDBY$PLSQL
(
  session_id   NUMBER,
  start_finish NUMBER,
  call_text    CLOB,
  spare1       NUMBER,
  spare2       NUMBER,
  spare3       VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$SCN
prompt ===========================
prompt
create table SYSTEM.LOGSTDBY$SCN
(
  obj#    NUMBER,
  objname VARCHAR2(4000),
  schema  VARCHAR2(30),
  type    VARCHAR2(20),
  scn     NUMBER,
  spare1  NUMBER,
  spare2  NUMBER,
  spare3  VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$SKIP
prompt ============================
prompt
create table SYSTEM.LOGSTDBY$SKIP
(
  error         NUMBER,
  statement_opt VARCHAR2(30),
  schema        VARCHAR2(30),
  name          VARCHAR2(30),
  use_like      NUMBER,
  esc           VARCHAR2(1),
  proc          VARCHAR2(98),
  active        NUMBER,
  spare1        NUMBER,
  spare2        NUMBER,
  spare3        VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$SKIP_SUPPORT
prompt ====================================
prompt
create table SYSTEM.LOGSTDBY$SKIP_SUPPORT
(
  action NUMBER not null,
  name   VARCHAR2(30) not null,
  spare1 NUMBER,
  spare2 NUMBER,
  spare3 VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LOGSTDBY$SKIP_TRANSACTION
prompt ========================================
prompt
create table SYSTEM.LOGSTDBY$SKIP_TRANSACTION
(
  xidusn     NUMBER,
  xidslt     NUMBER,
  xidsqn     NUMBER,
  active     NUMBER,
  commit_scn NUMBER,
  spare2     NUMBER,
  spare3     VARCHAR2(2000)
)
tablespace SYSAUX
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MEMBER
prompt =====================
prompt
create table SYSTEM.MEMBER
(
  id       VARCHAR2(32) default SYS_GUID() not null,
  name     VARCHAR2(20),
  nickname VARCHAR2(20),
  phonenum VARCHAR2(20),
  email    VARCHAR2(20)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MEMBER
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_LOG
prompt =============================
prompt
create table SYSTEM.MVIEW$_ADV_LOG
(
  runid#     NUMBER not null,
  filterid#  NUMBER,
  run_begin  DATE,
  run_end    DATE,
  run_type   NUMBER,
  uname      VARCHAR2(30),
  status     NUMBER not null,
  message    VARCHAR2(2000),
  completed  NUMBER,
  total      NUMBER,
  error_code VARCHAR2(20)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_LOG
  is 'Log all calls to summary advisory functions';
alter table SYSTEM.MVIEW$_ADV_LOG
  add constraint MVIEW$_ADV_LOG_PK primary key (RUNID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_AJG
prompt =============================
prompt
create table SYSTEM.MVIEW$_ADV_AJG
(
  ajgid#    NUMBER not null,
  runid#    NUMBER not null,
  ajgdeslen NUMBER not null,
  ajgdes    LONG RAW not null,
  hashvalue NUMBER not null,
  frequency NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_AJG
  is 'Anchor-join graph representation';
alter table SYSTEM.MVIEW$_ADV_AJG
  add constraint MVIEW$_ADV_AJG_PK primary key (AJGID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_AJG
  add constraint MVIEW$_ADV_AJG_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_WORKLOAD
prompt ==================================
prompt
create table SYSTEM.MVIEW$_ADV_WORKLOAD
(
  queryid#      NUMBER not null,
  collectionid# NUMBER not null,
  collecttime   DATE not null,
  application   VARCHAR2(64),
  cardinality   NUMBER,
  resultsize    NUMBER,
  uname         VARCHAR2(30) not null,
  qdate         DATE,
  priority      NUMBER,
  exec_time     NUMBER,
  sql_text      LONG not null,
  sql_textlen   NUMBER not null,
  sql_hash      NUMBER,
  sql_addr      RAW(16),
  frequency     NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_WORKLOAD
  is 'Shared workload repository for DBA users of summary advisor';
create index SYSTEM.MVIEW$_ADV_WORKLOAD_IDX_01 on SYSTEM.MVIEW$_ADV_WORKLOAD (COLLECTIONID#, QUERYID#)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_WORKLOAD
  add constraint MVIEW$_ADV_WORKLOAD_PK primary key (QUERYID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_BASETABLE
prompt ===================================
prompt
create table SYSTEM.MVIEW$_ADV_BASETABLE
(
  collectionid# NUMBER not null,
  queryid#      NUMBER not null,
  owner         VARCHAR2(30),
  table_name    VARCHAR2(30),
  table_type    NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_BASETABLE
  is 'Base tables refered by a query';
create index SYSTEM.MVIEW$_ADV_BASETABLE_IDX_01 on SYSTEM.MVIEW$_ADV_BASETABLE (QUERYID#)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_BASETABLE
  add constraint MVIEW$_ADV_BASETABLE_FK foreign key (QUERYID#)
  references SYSTEM.MVIEW$_ADV_WORKLOAD (QUERYID#);

prompt
prompt Creating table MVIEW$_ADV_CLIQUE
prompt ================================
prompt
create table SYSTEM.MVIEW$_ADV_CLIQUE
(
  cliqueid#    NUMBER not null,
  runid#       NUMBER not null,
  cliquedeslen NUMBER not null,
  cliquedes    LONG RAW not null,
  hashvalue    NUMBER not null,
  frequency    NUMBER not null,
  bytecost     NUMBER not null,
  rowsize      NUMBER not null,
  numrows      NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_CLIQUE
  is 'Table for storing canonical form of Clique queries';
alter table SYSTEM.MVIEW$_ADV_CLIQUE
  add constraint MVIEW$_ADV_CLIQUE_PK primary key (CLIQUEID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_CLIQUE
  add constraint MVIEW$_ADV_CLIQUE_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_ELIGIBLE
prompt ==================================
prompt
create table SYSTEM.MVIEW$_ADV_ELIGIBLE
(
  sumobjn#  NUMBER not null,
  runid#    NUMBER not null,
  bytecost  NUMBER not null,
  flags     NUMBER not null,
  frequency NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_ELIGIBLE
  is 'Summary management rewrite eligibility information';
alter table SYSTEM.MVIEW$_ADV_ELIGIBLE
  add constraint MVIEW$_ADV_ELIGIBLE_PK primary key (SUMOBJN#, RUNID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_ELIGIBLE
  add constraint MVIEW$_ADV_ELIGIBLE_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_EXCEPTIONS
prompt ====================================
prompt
create table SYSTEM.MVIEW$_ADV_EXCEPTIONS
(
  runid#         NUMBER,
  owner          VARCHAR2(30),
  table_name     VARCHAR2(30),
  dimension_name VARCHAR2(30),
  relationship   VARCHAR2(11),
  bad_rowid      ROWID
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_EXCEPTIONS
  is 'Output table for dimension validations';
alter table SYSTEM.MVIEW$_ADV_EXCEPTIONS
  add constraint MVIEW$_ADV_EXCEPTION_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_FILTER
prompt ================================
prompt
create table SYSTEM.MVIEW$_ADV_FILTER
(
  filterid#     NUMBER not null,
  subfilternum# NUMBER not null,
  subfiltertype NUMBER not null,
  str_value     VARCHAR2(1028),
  num_value1    NUMBER,
  num_value2    NUMBER,
  date_value1   DATE,
  date_value2   DATE
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_FILTER
  is 'Table for workload filter definition';
alter table SYSTEM.MVIEW$_ADV_FILTER
  add constraint MVIEW$_ADV_FILTER_PK primary key (FILTERID#, SUBFILTERNUM#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_FILTERINSTANCE
prompt ========================================
prompt
create table SYSTEM.MVIEW$_ADV_FILTERINSTANCE
(
  runid#        NUMBER not null,
  filterid#     NUMBER,
  subfilternum# NUMBER,
  subfiltertype NUMBER,
  str_value     VARCHAR2(1028),
  num_value1    NUMBER,
  num_value2    NUMBER,
  date_value1   DATE,
  date_value2   DATE
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_FILTERINSTANCE
  is 'Table for workload filter instance definition';
alter table SYSTEM.MVIEW$_ADV_FILTERINSTANCE
  add constraint MVIEW$_ADV_FILTERINSTANCE_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_FJG
prompt =============================
prompt
create table SYSTEM.MVIEW$_ADV_FJG
(
  fjgid#    NUMBER not null,
  ajgid#    NUMBER not null,
  fjgdeslen NUMBER not null,
  fjgdes    LONG RAW not null,
  hashvalue NUMBER not null,
  frequency NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_FJG
  is 'Representation for query join sub-graph not in AJG ';
alter table SYSTEM.MVIEW$_ADV_FJG
  add constraint MVIEW$_ADV_FJG_PK primary key (FJGID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_FJG
  add constraint MVIEW$_ADV_FJG_FK foreign key (AJGID#)
  references SYSTEM.MVIEW$_ADV_AJG (AJGID#);

prompt
prompt Creating table MVIEW$_ADV_GC
prompt ============================
prompt
create table SYSTEM.MVIEW$_ADV_GC
(
  gcid#     NUMBER not null,
  fjgid#    NUMBER not null,
  gcdeslen  NUMBER not null,
  gcdes     LONG RAW not null,
  hashvalue NUMBER not null,
  frequency NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_GC
  is 'Group-by columns of a query';
alter table SYSTEM.MVIEW$_ADV_GC
  add constraint MVIEW$_ADV_GC_PK primary key (GCID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_GC
  add constraint MVIEW$_ADV_GC_FK foreign key (FJGID#)
  references SYSTEM.MVIEW$_ADV_FJG (FJGID#);

prompt
prompt Creating table MVIEW$_ADV_INDEX
prompt ===============================
prompt
create table SYSTEM.MVIEW$_ADV_INDEX
(
  runid#        NUMBER not null,
  rank#         NUMBER not null,
  mvindex#      NUMBER not null,
  index_type    NUMBER,
  index_name    VARCHAR2(50),
  column_name   VARCHAR2(32),
  index_content VARCHAR2(2000),
  summary_owner VARCHAR2(32)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_INFO
prompt ==============================
prompt
create table SYSTEM.MVIEW$_ADV_INFO
(
  runid#  NUMBER not null,
  seq#    NUMBER not null,
  type    NUMBER not null,
  infolen NUMBER not null,
  info    LONG RAW,
  status  NUMBER,
  flag    NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_INFO
  is 'Internal table for passing information from the SQL analyzer';
alter table SYSTEM.MVIEW$_ADV_INFO
  add constraint MVIEW$_ADV_INFO_PK primary key (RUNID#, SEQ#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_INFO
  add constraint MVIEW$_ADV_INFO_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_JOURNAL
prompt =================================
prompt
create table SYSTEM.MVIEW$_ADV_JOURNAL
(
  runid#    NUMBER not null,
  seq#      NUMBER not null,
  timestamp DATE not null,
  flags     NUMBER not null,
  num       NUMBER,
  text      LONG,
  textlen   NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_JOURNAL
  is 'Summary advisor journal table for debugging and information';
alter table SYSTEM.MVIEW$_ADV_JOURNAL
  add constraint MVIEW$_ADV_JOURNAL_PK primary key (RUNID#, SEQ#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_JOURNAL
  add constraint MVIEW$_ADV_JOURNAL_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_LEVEL
prompt ===============================
prompt
create table SYSTEM.MVIEW$_ADV_LEVEL
(
  runid#     NUMBER not null,
  levelid#   NUMBER not null,
  dimobj#    NUMBER,
  flags      NUMBER not null,
  tblobj#    NUMBER not null,
  columnlist RAW(70) not null,
  levelname  VARCHAR2(30)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_LEVEL
  is 'Level definition';
alter table SYSTEM.MVIEW$_ADV_LEVEL
  add constraint MVIEW$_ADV_LEVEL_PK primary key (RUNID#, LEVELID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_LEVEL
  add constraint MVIEW$_ADV_LEVEL_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_OUTPUT
prompt ================================
prompt
create table SYSTEM.MVIEW$_ADV_OUTPUT
(
  runid#                NUMBER not null,
  output_type           NUMBER not null,
  rank#                 NUMBER not null,
  action_type           VARCHAR2(6),
  summary_owner         VARCHAR2(30),
  summary_name          VARCHAR2(30),
  group_by_columns      VARCHAR2(2000),
  where_clause          VARCHAR2(2000),
  from_clause           VARCHAR2(2000),
  measures_list         VARCHAR2(2000),
  fact_tables           VARCHAR2(1000),
  grouping_levels       VARCHAR2(2000),
  querylen              NUMBER,
  query_text            LONG,
  storage_in_bytes      NUMBER,
  pct_performance_gain  NUMBER,
  frequency             NUMBER,
  cumulative_benefit    NUMBER,
  benefit_to_cost_ratio NUMBER not null,
  validated             NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_OUTPUT
  is 'Output table for summary recommendations and evaluations';
alter table SYSTEM.MVIEW$_ADV_OUTPUT
  add constraint MVIEW$_ADV_OUTPUT_PK primary key (RUNID#, RANK#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_OUTPUT
  add constraint MVIEW$_ADV_OUTPUT_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);

prompt
prompt Creating table MVIEW$_ADV_OWB
prompt =============================
prompt
create global temporary table SYSTEM.MVIEW$_ADV_OWB
(
  runid#      NUMBER,
  objname     VARCHAR2(30),
  ownername   VARCHAR2(30),
  mvscript    CLOB,
  indexscript CLOB
)
on commit preserve rows;

prompt
prompt Creating table MVIEW$_ADV_PARAMETERS
prompt ====================================
prompt
create table SYSTEM.MVIEW$_ADV_PARAMETERS
(
  parameter_name  VARCHAR2(30) not null,
  parameter_type  NUMBER not null,
  string_value    VARCHAR2(30),
  date_value      DATE,
  numerical_value NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_PARAMETERS
  is 'Summary advisor tuning parameters';
alter table SYSTEM.MVIEW$_ADV_PARAMETERS
  add constraint MVIEW$_ADV_PARAMETERS_PK primary key (PARAMETER_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_PARTITION
prompt ===================================
prompt
create table SYSTEM.MVIEW$_ADV_PARTITION
(
  runid#        NUMBER not null,
  rank#         NUMBER not null,
  summary_owner VARCHAR2(32),
  query_text    LONG
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_PLAN
prompt ==============================
prompt
create table SYSTEM.MVIEW$_ADV_PLAN
(
  statement_id    VARCHAR2(30),
  timestamp       DATE,
  remarks         VARCHAR2(80),
  operation       VARCHAR2(30),
  options         VARCHAR2(255),
  object_node     VARCHAR2(128),
  object_owner    VARCHAR2(30),
  object_name     VARCHAR2(30),
  object_instance INTEGER,
  object_type     VARCHAR2(30),
  optimizer       VARCHAR2(255),
  search_columns  NUMBER,
  id              INTEGER,
  parent_id       INTEGER,
  position        INTEGER,
  cost            INTEGER,
  cardinality     INTEGER,
  bytes           INTEGER,
  other_tag       VARCHAR2(255),
  partition_start VARCHAR2(255),
  partition_stop  VARCHAR2(255),
  partition_id    INTEGER,
  other           LONG,
  distribution    VARCHAR2(30),
  cpu_cost        INTEGER,
  io_cost         INTEGER,
  temp_space      INTEGER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_PLAN
  is 'Private plan table for estimate_mview_size operations';

prompt
prompt Creating table MVIEW$_ADV_PRETTY
prompt ================================
prompt
create table SYSTEM.MVIEW$_ADV_PRETTY
(
  queryid# NUMBER,
  sql_text LONG
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_PRETTY
  is 'Table for sql parsing';
create index SYSTEM.MVIEW$_ADV_PRETTY_IDX_01 on SYSTEM.MVIEW$_ADV_PRETTY (QUERYID#)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_ROLLUP
prompt ================================
prompt
create table SYSTEM.MVIEW$_ADV_ROLLUP
(
  runid#    NUMBER not null,
  clevelid# NUMBER not null,
  plevelid# NUMBER not null,
  flags     NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_ROLLUP
  is 'Each row repesents either a functional dependency or join-key relationship';
alter table SYSTEM.MVIEW$_ADV_ROLLUP
  add constraint MVIEW$_ADV_ROLLUP_PK primary key (RUNID#, CLEVELID#, PLEVELID#)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.MVIEW$_ADV_ROLLUP
  add constraint MVIEW$_ADV_ROLLUP_CFK foreign key (RUNID#, CLEVELID#)
  references SYSTEM.MVIEW$_ADV_LEVEL (RUNID#, LEVELID#);
alter table SYSTEM.MVIEW$_ADV_ROLLUP
  add constraint MVIEW$_ADV_ROLLUP_FK foreign key (RUNID#)
  references SYSTEM.MVIEW$_ADV_LOG (RUNID#);
alter table SYSTEM.MVIEW$_ADV_ROLLUP
  add constraint MVIEW$_ADV_ROLLUP_PFK foreign key (RUNID#, PLEVELID#)
  references SYSTEM.MVIEW$_ADV_LEVEL (RUNID#, LEVELID#);

prompt
prompt Creating table MVIEW$_ADV_SQLDEPEND
prompt ===================================
prompt
create table SYSTEM.MVIEW$_ADV_SQLDEPEND
(
  collectionid# NUMBER,
  inst_id       NUMBER,
  from_address  RAW(16),
  from_hash     NUMBER,
  to_owner      VARCHAR2(64),
  to_name       VARCHAR2(1000),
  to_type       NUMBER,
  cardinality   NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_SQLDEPEND
  is 'Temporary table for workload collections';
create index SYSTEM.MVIEW$_ADV_SQLDEPEND_IDX_01 on SYSTEM.MVIEW$_ADV_SQLDEPEND (COLLECTIONID#, FROM_ADDRESS, FROM_HASH, INST_ID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MVIEW$_ADV_TEMP
prompt ==============================
prompt
create table SYSTEM.MVIEW$_ADV_TEMP
(
  id#  NUMBER,
  seq# NUMBER,
  text LONG
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.MVIEW$_ADV_TEMP
  is 'Table for temporary data';
create index SYSTEM.MVIEW$_ADV_TEMP_IDX_01 on SYSTEM.MVIEW$_ADV_TEMP (ID#, SEQ#)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table OL$
prompt ==================
prompt
create global temporary table SYSTEM.OL$
(
  ol_name     VARCHAR2(30),
  sql_text    LONG,
  textlen     NUMBER,
  signature   RAW(16),
  hash_value  NUMBER,
  hash_value2 NUMBER,
  category    VARCHAR2(30),
  version     VARCHAR2(64),
  creator     VARCHAR2(30),
  timestamp   DATE,
  flags       NUMBER,
  hintcount   NUMBER,
  spare1      NUMBER,
  spare2      VARCHAR2(1000)
)
on commit preserve rows;
create unique index SYSTEM.OL$NAME on SYSTEM.OL$ (OL_NAME);
create unique index SYSTEM.OL$SIGNATURE on SYSTEM.OL$ (SIGNATURE, CATEGORY);

prompt
prompt Creating table OL$HINTS
prompt =======================
prompt
create global temporary table SYSTEM.OL$HINTS
(
  ol_name         VARCHAR2(30),
  hint#           NUMBER,
  category        VARCHAR2(30),
  hint_type       NUMBER,
  hint_text       VARCHAR2(512),
  stage#          NUMBER,
  node#           NUMBER,
  table_name      VARCHAR2(30),
  table_tin       NUMBER,
  table_pos       NUMBER,
  ref_id          NUMBER,
  user_table_name VARCHAR2(64),
  cost            FLOAT,
  cardinality     FLOAT,
  bytes           FLOAT,
  hint_textoff    NUMBER,
  hint_textlen    NUMBER,
  join_pred       VARCHAR2(2000),
  spare1          NUMBER,
  spare2          NUMBER,
  hint_string     CLOB
)
on commit preserve rows;
create unique index SYSTEM.OL$HNT_NUM on SYSTEM.OL$HINTS (OL_NAME, HINT#);

prompt
prompt Creating table OL$NODES
prompt =======================
prompt
create global temporary table SYSTEM.OL$NODES
(
  ol_name      VARCHAR2(30),
  category     VARCHAR2(30),
  node_id      NUMBER,
  parent_id    NUMBER,
  node_type    NUMBER,
  node_textlen NUMBER,
  node_textoff NUMBER,
  node_name    VARCHAR2(64)
)
on commit preserve rows;

prompt
prompt Creating table PRODUCT
prompt ======================
prompt
create table SYSTEM.PRODUCT
(
  id            VARCHAR2(32) default SYS_GUID() not null,
  productnum    VARCHAR2(50) not null,
  productname   VARCHAR2(50),
  cityname      VARCHAR2(50),
  departuretime TIMESTAMP(6),
  productprice  NUMBER,
  productdesc   VARCHAR2(500),
  productstatus INTEGER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.PRODUCT
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.PRODUCT
  add constraint PRODUCT unique (ID, PRODUCTNUM)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ORDERS
prompt =====================
prompt
create table SYSTEM.ORDERS
(
  id          VARCHAR2(32) default SYS_GUID() not null,
  ordernum    VARCHAR2(20) not null,
  ordertime   TIMESTAMP(6),
  peoplecount INTEGER,
  orderdesc   VARCHAR2(500),
  paytype     INTEGER,
  orderstatus INTEGER,
  productid   VARCHAR2(32),
  memberid    VARCHAR2(32)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ORDERS
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ORDERS
  add unique (ORDERNUM)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ORDERS
  add foreign key (PRODUCTID)
  references SYSTEM.PRODUCT (ID);
alter table SYSTEM.ORDERS
  add foreign key (MEMBERID)
  references SYSTEM.MEMBER (ID);

prompt
prompt Creating table TRAVELLER
prompt ========================
prompt
create table SYSTEM.TRAVELLER
(
  id              VARCHAR2(32) default SYS_GUID() not null,
  name            VARCHAR2(20),
  sex             VARCHAR2(20),
  phonenum        VARCHAR2(20),
  credentialstype INTEGER,
  credentialsnum  VARCHAR2(50),
  travellertype   INTEGER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.TRAVELLER
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ORDER_TRAVELLER
prompt ==============================
prompt
create table SYSTEM.ORDER_TRAVELLER
(
  orderid     VARCHAR2(32) not null,
  travellerid VARCHAR2(32) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ORDER_TRAVELLER
  add primary key (ORDERID, TRAVELLERID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ORDER_TRAVELLER
  add foreign key (ORDERID)
  references SYSTEM.ORDERS (ID);
alter table SYSTEM.ORDER_TRAVELLER
  add foreign key (TRAVELLERID)
  references SYSTEM.TRAVELLER (ID);

prompt
prompt Creating table PERMISSION
prompt =========================
prompt
create table SYSTEM.PERMISSION
(
  id             VARCHAR2(32) default SYS_GUID() not null,
  permissionname VARCHAR2(50),
  url            VARCHAR2(50)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.PERMISSION
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_AUDIT_ATTRIBUTE
prompt ======================================
prompt
create table SYSTEM.REPCAT$_AUDIT_ATTRIBUTE
(
  attribute    VARCHAR2(30) not null,
  data_type_id INTEGER,
  data_length  INTEGER,
  source       VARCHAR2(92)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_AUDIT_ATTRIBUTE
  is 'Information about attributes automatically maintained for replication';
comment on column SYSTEM.REPCAT$_AUDIT_ATTRIBUTE.attribute
  is 'Description of the attribute';
comment on column SYSTEM.REPCAT$_AUDIT_ATTRIBUTE.data_type_id
  is 'Datatype of the attribute value';
comment on column SYSTEM.REPCAT$_AUDIT_ATTRIBUTE.data_length
  is 'Length of the attribute value in byte';
comment on column SYSTEM.REPCAT$_AUDIT_ATTRIBUTE.source
  is 'Name of the function which returns the attribute value';
alter table SYSTEM.REPCAT$_AUDIT_ATTRIBUTE
  add constraint REPCAT$_AUDIT_ATTRIBUTE_PK primary key (ATTRIBUTE)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_AUDIT_ATTRIBUTE
  add constraint REPCAT$_AUDIT_ATTRIBUTE_C1
  check ((data_type_id in (2, 4, 5, 6, 7) and
                  data_length is not null)
              or (data_type_id not in (2, 4, 5, 6, 7) and
                  data_length is null)
                 );
alter table SYSTEM.REPCAT$_AUDIT_ATTRIBUTE
  add constraint REPCAT$_AUDIT_ATTRIBUTE_NN1
  check ("DATA_TYPE_ID" IS NOT NULL);
alter table SYSTEM.REPCAT$_AUDIT_ATTRIBUTE
  add constraint REPCAT$_AUDIT_ATTRIBUTE_NN2
  check ("SOURCE" IS NOT NULL);

prompt
prompt Creating table REPCAT$_CONFLICT
prompt ===============================
prompt
create table SYSTEM.REPCAT$_CONFLICT
(
  sname            VARCHAR2(30) not null,
  oname            VARCHAR2(30) not null,
  conflict_type_id INTEGER not null,
  reference_name   VARCHAR2(30) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_CONFLICT
  is 'All conflicts for which users have specified resolutions in the database';
comment on column SYSTEM.REPCAT$_CONFLICT.sname
  is 'Owner of replicated object';
comment on column SYSTEM.REPCAT$_CONFLICT.oname
  is 'Name of the replicated object';
comment on column SYSTEM.REPCAT$_CONFLICT.conflict_type_id
  is 'Type of conflict';
comment on column SYSTEM.REPCAT$_CONFLICT.reference_name
  is 'Table name, unique constraint name, or column group name';
alter table SYSTEM.REPCAT$_CONFLICT
  add constraint REPCAT$_CONFLICT_PK primary key (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_CONFLICT
  add constraint REPCAT$_CONFLICT_C1
  check (conflict_type_id in (1, 2, 3));

prompt
prompt Creating table REPCAT$_AUDIT_COLUMN
prompt ===================================
prompt
create table SYSTEM.REPCAT$_AUDIT_COLUMN
(
  sname                 VARCHAR2(30) not null,
  oname                 VARCHAR2(30) not null,
  column_name           VARCHAR2(30) not null,
  base_sname            VARCHAR2(30),
  base_oname            VARCHAR2(30),
  base_conflict_type_id INTEGER,
  base_reference_name   VARCHAR2(30),
  attribute             VARCHAR2(30)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_AUDIT_COLUMN
  is 'Information about columns in all shadow tables for all replicated tables in the database';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.sname
  is 'Owner of the shadow table';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.oname
  is 'Name of the shadow table';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.column_name
  is 'Name of the column in the shadow table';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.base_sname
  is 'Owner of replicated table';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.base_oname
  is 'Name of the replicated table';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.base_conflict_type_id
  is 'Type of conflict';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.base_reference_name
  is 'Table name, unique constraint name, or column group name';
comment on column SYSTEM.REPCAT$_AUDIT_COLUMN.attribute
  is 'Description of the attribute';
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_PK primary key (COLUMN_NAME, ONAME, SNAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_F1 foreign key (ATTRIBUTE)
  references SYSTEM.REPCAT$_AUDIT_ATTRIBUTE (ATTRIBUTE);
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_F2 foreign key (BASE_SNAME, BASE_ONAME, BASE_CONFLICT_TYPE_ID, BASE_REFERENCE_NAME)
  references SYSTEM.REPCAT$_CONFLICT (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME);
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_NN1
  check ("BASE_SNAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_NN2
  check ("BASE_ONAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_NN3
  check ("BASE_CONFLICT_TYPE_ID" IS NOT NULL);
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_NN4
  check ("BASE_REFERENCE_NAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_AUDIT_COLUMN
  add constraint REPCAT$_AUDIT_COLUMN_NN5
  check ("ATTRIBUTE" IS NOT NULL);

prompt
prompt Creating table REPCAT$_COLUMN_GROUP
prompt ===================================
prompt
create table SYSTEM.REPCAT$_COLUMN_GROUP
(
  sname         VARCHAR2(30),
  oname         VARCHAR2(30),
  group_name    VARCHAR2(30),
  group_comment VARCHAR2(80)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_COLUMN_GROUP
  is 'All column groups of replicated tables in the database';
comment on column SYSTEM.REPCAT$_COLUMN_GROUP.sname
  is 'Owner of replicated object';
comment on column SYSTEM.REPCAT$_COLUMN_GROUP.oname
  is 'Name of the replicated object';
comment on column SYSTEM.REPCAT$_COLUMN_GROUP.group_name
  is 'Name of the column group';
comment on column SYSTEM.REPCAT$_COLUMN_GROUP.group_comment
  is 'Description of the column group';
alter table SYSTEM.REPCAT$_COLUMN_GROUP
  add constraint REPCAT$_COLUMN_GROUP_PK primary key (SNAME, ONAME, GROUP_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_COLUMN_GROUP
  add constraint REPCAT$_COLUMN_GROUP_NN1
  check ("SNAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_COLUMN_GROUP
  add constraint REPCAT$_COLUMN_GROUP_NN2
  check ("ONAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_COLUMN_GROUP
  add constraint REPCAT$_COLUMN_GROUP_NN3
  check ("GROUP_NAME" IS NOT NULL);

prompt
prompt Creating table REPCAT$_REPCATLOG
prompt ================================
prompt
create table SYSTEM.REPCAT$_REPCATLOG
(
  version      NUMBER,
  id           NUMBER not null,
  source       VARCHAR2(128) not null,
  userid       VARCHAR2(30),
  timestamp    DATE,
  role         VARCHAR2(1) not null,
  master       VARCHAR2(128) not null,
  sname        VARCHAR2(30),
  request      INTEGER,
  oname        VARCHAR2(30),
  type         INTEGER,
  a_comment    VARCHAR2(2000),
  bool_arg     VARCHAR2(1),
  ano_bool_arg VARCHAR2(1),
  int_arg      INTEGER,
  ano_int_arg  INTEGER,
  lines        INTEGER,
  status       INTEGER,
  message      VARCHAR2(200),
  errnum       NUMBER,
  gname        VARCHAR2(30)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REPCATLOG
  is 'Information about asynchronous administration requests';
comment on column SYSTEM.REPCAT$_REPCATLOG.version
  is 'Version of the repcat log record';
comment on column SYSTEM.REPCAT$_REPCATLOG.id
  is 'Identifying number of repcat log record';
comment on column SYSTEM.REPCAT$_REPCATLOG.source
  is 'Name of the database at which the request originated';
comment on column SYSTEM.REPCAT$_REPCATLOG.userid
  is 'Name of the user who submitted the request';
comment on column SYSTEM.REPCAT$_REPCATLOG.timestamp
  is 'When the request was submitted';
comment on column SYSTEM.REPCAT$_REPCATLOG.role
  is 'Is this database the masterdef for the request';
comment on column SYSTEM.REPCAT$_REPCATLOG.master
  is 'Name of the database that processes this request$_ddl';
comment on column SYSTEM.REPCAT$_REPCATLOG.sname
  is 'Schema of replicated object';
comment on column SYSTEM.REPCAT$_REPCATLOG.request
  is 'Name of the requested operation';
comment on column SYSTEM.REPCAT$_REPCATLOG.oname
  is 'Replicated object name, if applicable';
comment on column SYSTEM.REPCAT$_REPCATLOG.type
  is 'Type of replicated object, if applicable';
comment on column SYSTEM.REPCAT$_REPCATLOG.a_comment
  is 'Textual argument used for comments';
comment on column SYSTEM.REPCAT$_REPCATLOG.bool_arg
  is 'Boolean argument';
comment on column SYSTEM.REPCAT$_REPCATLOG.ano_bool_arg
  is 'Another Boolean argument';
comment on column SYSTEM.REPCAT$_REPCATLOG.int_arg
  is 'Integer argument';
comment on column SYSTEM.REPCAT$_REPCATLOG.ano_int_arg
  is 'Another integer argument';
comment on column SYSTEM.REPCAT$_REPCATLOG.lines
  is 'The number of rows in system.repcat$_ddl at the processing site';
comment on column SYSTEM.REPCAT$_REPCATLOG.status
  is 'Status of the request at this database';
comment on column SYSTEM.REPCAT$_REPCATLOG.message
  is 'Error message associated with processing the request';
comment on column SYSTEM.REPCAT$_REPCATLOG.errnum
  is 'Oracle error number associated with processing the request';
comment on column SYSTEM.REPCAT$_REPCATLOG.gname
  is 'Name of the replicated object group';
create index SYSTEM.REPCAT$_REPCATLOG_GNAME on SYSTEM.REPCAT$_REPCATLOG (GNAME, SNAME, ONAME, TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPCATLOG
  add constraint REPCAT$_REPCATLOG_PRIMARY primary key (ID, SOURCE, ROLE, MASTER)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPCATLOG
  add constraint REPCAT$_REPCATLOG_REQUEST
  check (request IN (-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                                       11, 12, 13, 14, 15, 16, 17,
                                       18, 19, 20, 21, 22, 23, 24, 25));
alter table SYSTEM.REPCAT$_REPCATLOG
  add constraint REPCAT$_REPCATLOG_STATUS
  check (status IN (0, 1, 2, 3, 4));
alter table SYSTEM.REPCAT$_REPCATLOG
  add constraint REPCAT$_REPCATLOG_TYPE
  check (type IN (-1, 0, 1, 2, 4, 5, 7, 8, 9, 11, 12, -3,
                                    13, 14, 32, 33));

prompt
prompt Creating table REPCAT$_DDL
prompt ==========================
prompt
create table SYSTEM.REPCAT$_DDL
(
  log_id  NUMBER,
  source  VARCHAR2(128),
  role    VARCHAR2(1),
  master  VARCHAR2(128),
  line    INTEGER,
  text    VARCHAR2(2000),
  ddl_num INTEGER default 1       -- order of ddls to execute
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_DDL
  is 'Arguments that do not fit in a single repcat log record';
comment on column SYSTEM.REPCAT$_DDL.log_id
  is 'Identifying number of the repcat log record';
comment on column SYSTEM.REPCAT$_DDL.source
  is 'Name of the database at which the request originated';
comment on column SYSTEM.REPCAT$_DDL.role
  is 'Is this database the masterdef for the request';
comment on column SYSTEM.REPCAT$_DDL.master
  is 'Name of the database that processes this request';
comment on column SYSTEM.REPCAT$_DDL.line
  is 'Ordering of records within a single request';
comment on column SYSTEM.REPCAT$_DDL.text
  is 'Portion of an argument';
comment on column SYSTEM.REPCAT$_DDL.ddl_num
  is 'Ordering of DDLs to execute';
create unique index SYSTEM.REPCAT$_DDL on SYSTEM.REPCAT$_DDL (LOG_ID, SOURCE, ROLE, MASTER, LINE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_DDL_INDEX on SYSTEM.REPCAT$_DDL (LOG_ID, SOURCE, ROLE, MASTER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_DDL
  add constraint REPCAT$_DDL_PRNT foreign key (LOG_ID, SOURCE, ROLE, MASTER)
  references SYSTEM.REPCAT$_REPCATLOG (ID, SOURCE, ROLE, MASTER) on delete cascade;

prompt
prompt Creating table REPCAT$_EXCEPTIONS
prompt =================================
prompt
create table SYSTEM.REPCAT$_EXCEPTIONS
(
  exception_id  NUMBER not null,
  user_name     VARCHAR2(30),
  request       CLOB,
  job           NUMBER,
  error_date    DATE,
  error_number  NUMBER,
  error_message VARCHAR2(4000),
  line_number   NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_EXCEPTIONS
  is 'Repcat processing exceptions table.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.exception_id
  is 'Internal primary key of the exceptions table.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.user_name
  is 'User name of user submitting the exception.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.request
  is 'Originating request containing the exception.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.job
  is 'Originating job containing the exception.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.error_date
  is 'Date of occurance for the exception.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.error_number
  is 'Error number generating the exception.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.error_message
  is 'Error message associated with the error generating the exception.';
comment on column SYSTEM.REPCAT$_EXCEPTIONS.line_number
  is 'Line number of the exception.';
alter table SYSTEM.REPCAT$_EXCEPTIONS
  add constraint REPCAT$_EXCEPTIONS_PK primary key (EXCEPTION_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_EXTENSION
prompt ================================
prompt
create table SYSTEM.REPCAT$_EXTENSION
(
  extension_id                RAW(16) not null,
  extension_code              NUMBER,
  masterdef                   VARCHAR2(128),
  export_required             VARCHAR2(1),
  repcatlog_id                NUMBER,
  extension_status            NUMBER,
  flashback_scn               NUMBER,
  push_to_mdef                VARCHAR2(1),
  push_to_new                 VARCHAR2(1),
  percentage_for_catchup_mdef NUMBER,
  cycle_seconds_mdef          NUMBER,
  percentage_for_catchup_new  NUMBER,
  cycle_seconds_new           NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_EXTENSION
  is 'Information about replication extension requests';
comment on column SYSTEM.REPCAT$_EXTENSION.extension_id
  is 'Globally unique identifier for replication extension';
comment on column SYSTEM.REPCAT$_EXTENSION.extension_code
  is 'Kind of replication extension';
comment on column SYSTEM.REPCAT$_EXTENSION.masterdef
  is 'Master definition site for replication extension';
comment on column SYSTEM.REPCAT$_EXTENSION.export_required
  is 'YES if this extension requires an export, and NO if no export is required';
comment on column SYSTEM.REPCAT$_EXTENSION.repcatlog_id
  is 'Identifier of repcatlog records related to replication extension';
comment on column SYSTEM.REPCAT$_EXTENSION.extension_status
  is 'Status of replication extension';
comment on column SYSTEM.REPCAT$_EXTENSION.flashback_scn
  is 'Flashback_scn for export or change-based recovery for replication extension';
comment on column SYSTEM.REPCAT$_EXTENSION.push_to_mdef
  is 'YES if existing masters partially push to masterdef, NO if no pushing';
comment on column SYSTEM.REPCAT$_EXTENSION.push_to_new
  is 'YES if existing masters partially push to new masters, NO if no pushing';
comment on column SYSTEM.REPCAT$_EXTENSION.percentage_for_catchup_mdef
  is 'Fraction of push to masterdef cycle devoted to catching up';
comment on column SYSTEM.REPCAT$_EXTENSION.cycle_seconds_mdef
  is 'Length of push to masterdef cycle when catching up';
comment on column SYSTEM.REPCAT$_EXTENSION.percentage_for_catchup_new
  is 'Fraction of push to new masters cycle devoted to catching up';
comment on column SYSTEM.REPCAT$_EXTENSION.cycle_seconds_new
  is 'Length of push to new masters cycle when catching up';
alter table SYSTEM.REPCAT$_EXTENSION
  add primary key (EXTENSION_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_EXTENSION
  add constraint REPCAT$_EXTENSION_CODE
  check (extension_code IN (0));
alter table SYSTEM.REPCAT$_EXTENSION
  add constraint REPCAT$_EXTENSION_EXPORTREQ
  check (export_required IN ('Y', 'N'));
alter table SYSTEM.REPCAT$_EXTENSION
  add constraint REPCAT$_EXTENSION_PUSH_TO_MDEF
  check (push_to_mdef IN ('Y', 'N'));
alter table SYSTEM.REPCAT$_EXTENSION
  add constraint REPCAT$_EXTENSION_PUSH_TO_NEW
  check (push_to_new IN ('Y', 'N'));
alter table SYSTEM.REPCAT$_EXTENSION
  add constraint REPCAT$_EXTENSION_STATUS
  check (extension_status IN (0, 1, 2, 3, 4));

prompt
prompt Creating table REPCAT$_REPCAT
prompt =============================
prompt
create table SYSTEM.REPCAT$_REPCAT
(
  gowner         VARCHAR2(30) default 'PUBLIC' not null,
  sname          VARCHAR2(30) not null,
  master         VARCHAR2(1),
  status         INTEGER,
  schema_comment VARCHAR2(80),
  flavor_id      NUMBER,
  flag           RAW(4) default '00000000'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REPCAT
  is 'Information about all replicated object groups';
comment on column SYSTEM.REPCAT$_REPCAT.gowner
  is 'Owner of the object group';
comment on column SYSTEM.REPCAT$_REPCAT.sname
  is 'Name of the replicated object group';
comment on column SYSTEM.REPCAT$_REPCAT.master
  is 'Is the site a master site for the replicated object group';
comment on column SYSTEM.REPCAT$_REPCAT.status
  is 'If the site is a master, the master''s status';
comment on column SYSTEM.REPCAT$_REPCAT.schema_comment
  is 'Description of the replicated object group';
comment on column SYSTEM.REPCAT$_REPCAT.flavor_id
  is 'Flavor identifier';
comment on column SYSTEM.REPCAT$_REPCAT.flag
  is 'Miscellaneous repgroup info';
alter table SYSTEM.REPCAT$_REPCAT
  add constraint REPCAT$_REPCAT_PRIMARY primary key (SNAME, GOWNER)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPCAT
  add constraint REPCAT$_REPCAT_STATUS
  check (status IN (0, 1, 2));

prompt
prompt Creating table REPCAT$_FLAVORS
prompt ==============================
prompt
create table SYSTEM.REPCAT$_FLAVORS
(
  flavor_id     NUMBER not null,
  gowner        VARCHAR2(30) default 'PUBLIC',
  gname         VARCHAR2(30) not null,
  fname         VARCHAR2(30),
  creation_date DATE default SYSDATE,
  created_by    NUMBER default UID,
  published     VARCHAR2(1) default 'N'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_FLAVORS
  is 'Flavors defined for replicated object groups';
comment on column SYSTEM.REPCAT$_FLAVORS.flavor_id
  is 'Flavor identifier, unique within object group';
comment on column SYSTEM.REPCAT$_FLAVORS.gowner
  is 'Owner of the object group';
comment on column SYSTEM.REPCAT$_FLAVORS.gname
  is 'Name of the object group';
comment on column SYSTEM.REPCAT$_FLAVORS.fname
  is 'Name of the flavor';
comment on column SYSTEM.REPCAT$_FLAVORS.creation_date
  is 'Date on which the flavor was created';
comment on column SYSTEM.REPCAT$_FLAVORS.created_by
  is 'Identifier of user that created the flavor';
comment on column SYSTEM.REPCAT$_FLAVORS.published
  is 'Indicates whether flavor is published (Y/N) or obsolete (O)';
create index SYSTEM.REPCAT$_FLAVORS_FK1_IDX on SYSTEM.REPCAT$_FLAVORS (GNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_FLAVORS_FNAME on SYSTEM.REPCAT$_FLAVORS (FNAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create unique index SYSTEM.REPCAT$_FLAVORS_GNAME on SYSTEM.REPCAT$_FLAVORS (GNAME, FNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_FLAVORS
  add constraint REPCAT$_FLAVORS_UNQ1 unique (GNAME, FLAVOR_ID, GOWNER)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_FLAVORS
  add constraint REPCAT$_FLAVORS_FK1 foreign key (GNAME, GOWNER)
  references SYSTEM.REPCAT$_REPCAT (SNAME, GOWNER) on delete cascade;
alter table SYSTEM.REPCAT$_FLAVORS
  add constraint REPCAT$_FLAVORS_C2
  check (published is NULL or (published in ('Y','N','O')));

prompt
prompt Creating table REPCAT$_FLAVOR_OBJECTS
prompt =====================================
prompt
create table SYSTEM.REPCAT$_FLAVOR_OBJECTS
(
  flavor_id       NUMBER not null,
  gowner          VARCHAR2(30) default 'PUBLIC' not null,
  gname           VARCHAR2(30) not null,
  sname           VARCHAR2(30) not null,
  oname           VARCHAR2(30) not null,
  type            NUMBER not null,
  version#        NUMBER,
  hashcode        RAW(17),
  columns_present RAW(125)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_FLAVOR_OBJECTS
  is 'Replicated objects in flavors';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.flavor_id
  is 'Flavor identifier';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.gowner
  is 'Owner of the object group containing object';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.gname
  is 'Object group containing object';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.sname
  is 'Schema containing object';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.oname
  is 'Name of object';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.type
  is 'Object type';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.version#
  is 'Version# of a user-defined type';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.hashcode
  is 'Hashcode of a user-defined type';
comment on column SYSTEM.REPCAT$_FLAVOR_OBJECTS.columns_present
  is 'For tables, encoded mapping of columns present';
create index SYSTEM.REPCAT$_FLAVOR_OBJECTS_FG on SYSTEM.REPCAT$_FLAVOR_OBJECTS (FLAVOR_ID, GNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_FLAVOR_OBJECTS_FK1_IDX on SYSTEM.REPCAT$_FLAVOR_OBJECTS (GNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_FLAVOR_OBJECTS_FK2_IDX on SYSTEM.REPCAT$_FLAVOR_OBJECTS (GNAME, FLAVOR_ID, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_FLAVOR_OBJECTS
  add constraint REPCAT$_FLAVOR_OBJECTS_PK primary key (SNAME, ONAME, TYPE, GNAME, FLAVOR_ID, GOWNER)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_FLAVOR_OBJECTS
  add constraint REPCAT$_FLAVOR_OBJECTS_FK1 foreign key (GNAME, GOWNER)
  references SYSTEM.REPCAT$_REPCAT (SNAME, GOWNER) on delete cascade;
alter table SYSTEM.REPCAT$_FLAVOR_OBJECTS
  add constraint REPCAT$_FLAVOR_OBJECTS_FK2 foreign key (GNAME, FLAVOR_ID, GOWNER)
  references SYSTEM.REPCAT$_FLAVORS (GNAME, FLAVOR_ID, GOWNER) on delete cascade;
alter table SYSTEM.REPCAT$_FLAVOR_OBJECTS
  add constraint REPCAT$_FLAVOR_OBJECTS_VERSION
  check (version# >= 0 AND version# < 65536);

prompt
prompt Creating table REPCAT$_REPOBJECT
prompt ================================
prompt
create table SYSTEM.REPCAT$_REPOBJECT
(
  sname          VARCHAR2(30) not null,
  oname          VARCHAR2(30) not null,
  type           INTEGER not null,
  version#       NUMBER,
  hashcode       RAW(17),
  id             NUMBER,
  object_comment VARCHAR2(80),
  status         INTEGER,
  genpackage     INTEGER,
  genplogid      INTEGER,
  gentrigger     INTEGER,
  gentlogid      INTEGER,
  gowner         VARCHAR2(30),
  gname          VARCHAR2(30),
  flag           RAW(4) default '00000000'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REPOBJECT
  is 'Information about replicated objects';
comment on column SYSTEM.REPCAT$_REPOBJECT.sname
  is 'Name of the object owner';
comment on column SYSTEM.REPCAT$_REPOBJECT.oname
  is 'Name of the object';
comment on column SYSTEM.REPCAT$_REPOBJECT.type
  is 'Type of the object';
comment on column SYSTEM.REPCAT$_REPOBJECT.version#
  is 'Version of objects of TYPE';
comment on column SYSTEM.REPCAT$_REPOBJECT.hashcode
  is 'Hashcode of objects of TYPE';
comment on column SYSTEM.REPCAT$_REPOBJECT.id
  is 'Identifier of the local object';
comment on column SYSTEM.REPCAT$_REPOBJECT.object_comment
  is 'Description of the replicated object';
comment on column SYSTEM.REPCAT$_REPOBJECT.status
  is 'Status of the last create or alter request on the local object';
comment on column SYSTEM.REPCAT$_REPOBJECT.genpackage
  is 'Status of whether the object needs to generate replication package';
comment on column SYSTEM.REPCAT$_REPOBJECT.genplogid
  is 'Log id of message sent for generating package support';
comment on column SYSTEM.REPCAT$_REPOBJECT.gentrigger
  is 'Status of whether the object needs to generate replication trigger';
comment on column SYSTEM.REPCAT$_REPOBJECT.gentlogid
  is 'Log id of message sent for generating trigger support';
comment on column SYSTEM.REPCAT$_REPOBJECT.gowner
  is 'Owner of the object''s object group';
comment on column SYSTEM.REPCAT$_REPOBJECT.gname
  is 'Name of the object''s object group';
comment on column SYSTEM.REPCAT$_REPOBJECT.flag
  is 'Information about replicated object';
create index SYSTEM.REPCAT$_REPOBJECT_GNAME on SYSTEM.REPCAT$_REPOBJECT (GNAME, ONAME, TYPE, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_REPOBJECT_PRNT_IDX on SYSTEM.REPCAT$_REPOBJECT (GNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPOBJECT
  add constraint REPCAT$_REPOBJECT_PRIMARY primary key (SNAME, ONAME, TYPE)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPOBJECT
  add constraint REPCAT$_REPOBJECT_PRNT foreign key (GNAME, GOWNER)
  references SYSTEM.REPCAT$_REPCAT (SNAME, GOWNER) on delete cascade;
alter table SYSTEM.REPCAT$_REPOBJECT
  add constraint REPCAT$_REPOBJECT_GENPACKAGE
  check (genpackage IN (0, 1, 2));
alter table SYSTEM.REPCAT$_REPOBJECT
  add constraint REPCAT$_REPOBJECT_GENTRIGGER
  check (gentrigger IN (0, 1, 2));
alter table SYSTEM.REPCAT$_REPOBJECT
  add constraint REPCAT$_REPOBJECT_STATUS
  check (status IN (0, 1, 2, 3, 4, 5, 6));
alter table SYSTEM.REPCAT$_REPOBJECT
  add constraint REPCAT$_REPOBJECT_TYPE
  check (type IN (-1, 1, 2, 4, 5, 7, 8, 9, 11, 12, -3,
                                      -4, 13, 14, 32, 33));
alter table SYSTEM.REPCAT$_REPOBJECT
  add constraint REPCAT$_REPOBJECT_VERSION
  check (version# >= 0 AND version# < 65536);

prompt
prompt Creating table REPCAT$_GENERATED
prompt ================================
prompt
create table SYSTEM.REPCAT$_GENERATED
(
  sname            VARCHAR2(30) not null,
  oname            VARCHAR2(30) not null,
  type             INTEGER not null,
  reason           NUMBER,
  base_sname       VARCHAR2(30) not null,
  base_oname       VARCHAR2(30) not null,
  base_type        INTEGER not null,
  package_prefix   VARCHAR2(30),
  procedure_prefix VARCHAR2(30),
  distributed      VARCHAR2(1)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_GENERATED
  is 'Objects generated to support replication';
comment on column SYSTEM.REPCAT$_GENERATED.sname
  is 'Schema containing the generated object';
comment on column SYSTEM.REPCAT$_GENERATED.oname
  is 'Name of the generated object';
comment on column SYSTEM.REPCAT$_GENERATED.type
  is 'Type of the generated object';
comment on column SYSTEM.REPCAT$_GENERATED.reason
  is 'Reason the object was generated';
comment on column SYSTEM.REPCAT$_GENERATED.base_sname
  is 'Name of the object''s owner';
comment on column SYSTEM.REPCAT$_GENERATED.base_oname
  is 'Name of the object';
comment on column SYSTEM.REPCAT$_GENERATED.base_type
  is 'Type of the object';
comment on column SYSTEM.REPCAT$_GENERATED.package_prefix
  is 'Prefix for package wrapper';
comment on column SYSTEM.REPCAT$_GENERATED.procedure_prefix
  is 'Procedure prefix for package wrapper or procedure wrapper';
comment on column SYSTEM.REPCAT$_GENERATED.distributed
  is 'Is the generated object separately generated at each master';
create index SYSTEM.REPCAT$_GENERATED_N1 on SYSTEM.REPCAT$_GENERATED (BASE_SNAME, BASE_ONAME, BASE_TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_REPGEN_PRNT_IDX on SYSTEM.REPCAT$_GENERATED (SNAME, ONAME, TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_GENERATED
  add constraint REPCAT$_REPGEN_PRIMARY primary key (SNAME, ONAME, TYPE, BASE_SNAME, BASE_ONAME, BASE_TYPE)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_GENERATED
  add constraint REPCAT$_REPGEN_PRNT foreign key (SNAME, ONAME, TYPE)
  references SYSTEM.REPCAT$_REPOBJECT (SNAME, ONAME, TYPE) on delete cascade;
alter table SYSTEM.REPCAT$_GENERATED
  add constraint REPCAT$_REPGEN_PRNT2 foreign key (BASE_SNAME, BASE_ONAME, BASE_TYPE)
  references SYSTEM.REPCAT$_REPOBJECT (SNAME, ONAME, TYPE) on delete cascade;
alter table SYSTEM.REPCAT$_GENERATED
  add constraint REPCAT$_GENERATED_OBJ
  check (reason IN (0, 1, 2, 3, 4, 5, 6, 7, 9, 10));

prompt
prompt Creating table REPCAT$_GROUPED_COLUMN
prompt =====================================
prompt
create table SYSTEM.REPCAT$_GROUPED_COLUMN
(
  sname       VARCHAR2(30) not null,
  oname       VARCHAR2(30) not null,
  group_name  VARCHAR2(30) not null,
  column_name VARCHAR2(30) not null,
  pos         NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_GROUPED_COLUMN
  is 'Columns in all column groups of replicated tables in the database';
comment on column SYSTEM.REPCAT$_GROUPED_COLUMN.sname
  is 'Owner of replicated object';
comment on column SYSTEM.REPCAT$_GROUPED_COLUMN.oname
  is 'Name of the replicated object';
comment on column SYSTEM.REPCAT$_GROUPED_COLUMN.group_name
  is 'Name of the column group';
comment on column SYSTEM.REPCAT$_GROUPED_COLUMN.column_name
  is 'Name of the column in the column group';
comment on column SYSTEM.REPCAT$_GROUPED_COLUMN.pos
  is 'Position of a column or an attribute in the table';
create index SYSTEM.REPCAT$_GROUPED_COLUMN_F1_IDX on SYSTEM.REPCAT$_GROUPED_COLUMN (SNAME, ONAME, GROUP_NAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_GROUPED_COLUMN
  add constraint REPCAT$_GROUPED_COLUMN_PK primary key (SNAME, ONAME, GROUP_NAME, COLUMN_NAME, POS)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_GROUPED_COLUMN
  add constraint REPCAT$_GROUPED_COLUMN_F1 foreign key (SNAME, ONAME, GROUP_NAME)
  references SYSTEM.REPCAT$_COLUMN_GROUP (SNAME, ONAME, GROUP_NAME);

prompt
prompt Creating table REPCAT$_TEMPLATE_STATUS
prompt ======================================
prompt
create table SYSTEM.REPCAT$_TEMPLATE_STATUS
(
  template_status_id NUMBER not null,
  status_type_name   VARCHAR2(100) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_TEMPLATE_STATUS
  is 'Table for template status and template status codes.';
comment on column SYSTEM.REPCAT$_TEMPLATE_STATUS.template_status_id
  is 'Internal primary key for the template status table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_STATUS.status_type_name
  is 'User friendly name for the template status.';
alter table SYSTEM.REPCAT$_TEMPLATE_STATUS
  add constraint REPCAT$_TEMPLATE_STATUS_PK primary key (TEMPLATE_STATUS_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_TEMPLATE_TYPES
prompt =====================================
prompt
create table SYSTEM.REPCAT$_TEMPLATE_TYPES
(
  template_type_id     NUMBER not null,
  template_description VARCHAR2(200),
  flags                RAW(255),
  spare1               VARCHAR2(4000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_TEMPLATE_TYPES
  is 'Internal table for maintaining types of templates.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TYPES.template_type_id
  is 'Internal primary key of the template types table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TYPES.template_description
  is 'Description of the template type.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TYPES.flags
  is 'Bitmap flags controlling each type of template.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TYPES.spare1
  is 'Reserved for future expansion.';
alter table SYSTEM.REPCAT$_TEMPLATE_TYPES
  add constraint REPCAT$_TEMPLATE_TYPES_PK primary key (TEMPLATE_TYPE_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_REFRESH_TEMPLATES
prompt ========================================
prompt
create table SYSTEM.REPCAT$_REFRESH_TEMPLATES
(
  refresh_template_id   NUMBER not null,
  owner                 VARCHAR2(30) not null,
  refresh_group_name    VARCHAR2(30) not null,
  refresh_template_name VARCHAR2(30) not null,
  template_comment      VARCHAR2(2000),
  public_template       VARCHAR2(1),
  last_modified         DATE,
  modified_by           NUMBER,
  creation_date         DATE,
  created_by            NUMBER,
  refresh_group_id      NUMBER default 0 not null,
  template_type_id      NUMBER default 1 not null,
  template_status_id    NUMBER default 0 not null,
  flags                 RAW(255),
  spare1                VARCHAR2(4000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REFRESH_TEMPLATES
  is 'Primary table containing deployment template information.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.refresh_template_id
  is 'Internal primary key of the REPCAT$_REFRESH_TEMPLATES table.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.owner
  is 'Owner of the refresh group template.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.refresh_group_name
  is 'Name of the refresh group to create during instantiation.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.refresh_template_name
  is 'Name of the refresh group template.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.template_comment
  is 'Optional comment field for the refresh group template.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.public_template
  is 'Flag specifying public template or private template.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.last_modified
  is 'Date the row was last modified.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.modified_by
  is 'User id of the user that modified the row.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.creation_date
  is 'Date the row was created.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.created_by
  is 'User id of the user that created the row.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.refresh_group_id
  is 'Internal primary key to default refresh group for the template.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.template_type_id
  is 'Internal primary key to the template types.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.template_status_id
  is 'Internal primary key to the template status table.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.flags
  is 'Internal flags for the template.';
comment on column SYSTEM.REPCAT$_REFRESH_TEMPLATES.spare1
  is 'Reserved for future use.';
alter table SYSTEM.REPCAT$_REFRESH_TEMPLATES
  add constraint REPCAT$_REFRESH_TEMPLATES_PK primary key (REFRESH_TEMPLATE_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REFRESH_TEMPLATES
  add constraint REPCAT$_REFRESH_TEMPLATES_U1 unique (REFRESH_TEMPLATE_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REFRESH_TEMPLATES
  add constraint REPCAT$_REFRESH_TEMPLATES_FK1 foreign key (TEMPLATE_TYPE_ID)
  references SYSTEM.REPCAT$_TEMPLATE_TYPES (TEMPLATE_TYPE_ID);
alter table SYSTEM.REPCAT$_REFRESH_TEMPLATES
  add constraint REPCAT$_REFRESH_TEMPLATES_FK2 foreign key (TEMPLATE_STATUS_ID)
  references SYSTEM.REPCAT$_TEMPLATE_STATUS (TEMPLATE_STATUS_ID);
alter table SYSTEM.REPCAT$_REFRESH_TEMPLATES
  add constraint REFRESH_TEMPLATES_C1
  check ((public_template in ('Y','N'))
   or public_template is NULL);

prompt
prompt Creating table REPCAT$_INSTANTIATION_DDL
prompt ========================================
prompt
create table SYSTEM.REPCAT$_INSTANTIATION_DDL
(
  refresh_template_id NUMBER not null,
  ddl_text            CLOB,
  ddl_num             NUMBER not null,
  phase               NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_INSTANTIATION_DDL
  is 'Table containing supplementary DDL to be executed during instantiation.';
comment on column SYSTEM.REPCAT$_INSTANTIATION_DDL.refresh_template_id
  is 'Primary key of template containing supplementary DDL.';
comment on column SYSTEM.REPCAT$_INSTANTIATION_DDL.ddl_text
  is 'Supplementary DDL string.';
comment on column SYSTEM.REPCAT$_INSTANTIATION_DDL.ddl_num
  is 'Column for ordering of supplementary DDL.';
comment on column SYSTEM.REPCAT$_INSTANTIATION_DDL.phase
  is 'Phase to execute the DDL string.';
alter table SYSTEM.REPCAT$_INSTANTIATION_DDL
  add constraint REPCAT$_INSTANTIATION_DDL_PK primary key (REFRESH_TEMPLATE_ID, PHASE, DDL_NUM)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_INSTANTIATION_DDL
  add constraint REPCAT$_INSTANTIATION_DDL_FK1 foreign key (REFRESH_TEMPLATE_ID)
  references SYSTEM.REPCAT$_REFRESH_TEMPLATES (REFRESH_TEMPLATE_ID) on delete cascade;

prompt
prompt Creating table REPCAT$_KEY_COLUMNS
prompt ==================================
prompt
create table SYSTEM.REPCAT$_KEY_COLUMNS
(
  sname VARCHAR2(30) not null,
  oname VARCHAR2(30) not null,
  type  INTEGER,
  col   VARCHAR2(30) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_KEY_COLUMNS
  is 'Primary columns for a table using column-level replication';
comment on column SYSTEM.REPCAT$_KEY_COLUMNS.sname
  is 'Schema containing table';
comment on column SYSTEM.REPCAT$_KEY_COLUMNS.oname
  is 'Name of the table';
comment on column SYSTEM.REPCAT$_KEY_COLUMNS.type
  is 'Type identifier';
comment on column SYSTEM.REPCAT$_KEY_COLUMNS.col
  is 'Column in the table';
create index SYSTEM.REPCAT$_KEY_COLUMNS_PRNT_IDX on SYSTEM.REPCAT$_KEY_COLUMNS (SNAME, ONAME, TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_KEY_COLUMNS
  add constraint REPCAT$_KEY_COLUMNS_PRIMARY primary key (SNAME, ONAME, COL)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_KEY_COLUMNS
  add constraint REPCAT$_KEY_COLUMNS_PRNT foreign key (SNAME, ONAME, TYPE)
  references SYSTEM.REPCAT$_REPOBJECT (SNAME, ONAME, TYPE) on delete cascade;

prompt
prompt Creating table REPCAT$_OBJECT_TYPES
prompt ===================================
prompt
create table SYSTEM.REPCAT$_OBJECT_TYPES
(
  object_type_id   NUMBER not null,
  object_type_name VARCHAR2(200),
  flags            RAW(255),
  spare1           VARCHAR2(4000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_OBJECT_TYPES
  is 'Internal table for template object types.';
comment on column SYSTEM.REPCAT$_OBJECT_TYPES.object_type_id
  is 'Internal primary key of the template object types table.';
comment on column SYSTEM.REPCAT$_OBJECT_TYPES.object_type_name
  is 'Descriptive name for the object type.';
comment on column SYSTEM.REPCAT$_OBJECT_TYPES.flags
  is 'Internal flags for object type processing.';
comment on column SYSTEM.REPCAT$_OBJECT_TYPES.spare1
  is 'Reserved for future use.';
alter table SYSTEM.REPCAT$_OBJECT_TYPES
  add constraint REPCAT$_OBJECT_TYPE_PK primary key (OBJECT_TYPE_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_TEMPLATE_OBJECTS
prompt =======================================
prompt
create table SYSTEM.REPCAT$_TEMPLATE_OBJECTS
(
  template_object_id   NUMBER not null,
  refresh_template_id  NUMBER not null,
  object_name          VARCHAR2(30) not null,
  object_type          NUMBER not null,
  object_version#      NUMBER,
  ddl_text             CLOB,
  master_rollback_seg  VARCHAR2(30),
  derived_from_sname   VARCHAR2(30),
  derived_from_oname   VARCHAR2(30),
  flavor_id            NUMBER,
  schema_name          VARCHAR2(30),
  ddl_num              NUMBER default 1 not null,
  template_refgroup_id NUMBER default 0 not null,
  flags                RAW(255),
  spare1               VARCHAR2(4000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.template_object_id
  is 'Internal primary key of the REPCAT$_TEMPLATE_OBJECTS table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.refresh_template_id
  is 'Internal primary key of the REPCAT$_REFRESH_TEMPLATES table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.object_name
  is 'Name of the database object.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.object_type
  is 'Type of database object.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.object_version#
  is 'Version# of database object of TYPE.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.ddl_text
  is 'DDL string for creating the object or WHERE clause for snapshot query.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.master_rollback_seg
  is 'Rollback segment for use during snapshot refreshes.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.derived_from_sname
  is 'Schema name of schema containing object this was derived from.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.derived_from_oname
  is 'Object name of object this object was derived from.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.flavor_id
  is 'Foreign key to the REPCAT$_FLAVORS table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.schema_name
  is 'Schema containing the object.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.ddl_num
  is 'Order of ddls to execute.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.template_refgroup_id
  is 'Internal ID of the refresh group to contain the object.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.flags
  is 'Internal flags for the object.';
comment on column SYSTEM.REPCAT$_TEMPLATE_OBJECTS.spare1
  is 'Reserved for future use.';
create index SYSTEM.REPCAT$_TEMPLATE_OBJECTS_N1 on SYSTEM.REPCAT$_TEMPLATE_OBJECTS (REFRESH_TEMPLATE_ID, OBJECT_TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_TEMPLATE_OBJECTS_N2 on SYSTEM.REPCAT$_TEMPLATE_OBJECTS (REFRESH_TEMPLATE_ID, OBJECT_NAME, SCHEMA_NAME, OBJECT_TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_OBJECTS
  add constraint REPCAT$_TEMPLATE_OBJECTS_PK primary key (TEMPLATE_OBJECT_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_OBJECTS
  add constraint REPCAT$_TEMPLATE_OBJECTS_U1 unique (OBJECT_NAME, OBJECT_TYPE, REFRESH_TEMPLATE_ID, SCHEMA_NAME, DDL_NUM)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_OBJECTS
  add constraint REPCAT$_TEMPLATE_OBJECTS_FK1 foreign key (REFRESH_TEMPLATE_ID)
  references SYSTEM.REPCAT$_REFRESH_TEMPLATES (REFRESH_TEMPLATE_ID) on delete cascade;
alter table SYSTEM.REPCAT$_TEMPLATE_OBJECTS
  add constraint REPCAT$_TEMPLATE_OBJECTS_FK3 foreign key (OBJECT_TYPE)
  references SYSTEM.REPCAT$_OBJECT_TYPES (OBJECT_TYPE_ID);
alter table SYSTEM.REPCAT$_TEMPLATE_OBJECTS
  add constraint REPCAT$_TEMPLATE_OBJECTS_VER
  check (object_version# >= 0 AND object_version# < 65536);

prompt
prompt Creating table REPCAT$_TEMPLATE_PARMS
prompt =====================================
prompt
create table SYSTEM.REPCAT$_TEMPLATE_PARMS
(
  template_parameter_id NUMBER not null,
  refresh_template_id   NUMBER not null,
  parameter_name        VARCHAR2(30) not null,
  default_parm_value    CLOB,
  prompt_string         VARCHAR2(2000),
  user_override         VARCHAR2(1) default 'Y'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column SYSTEM.REPCAT$_TEMPLATE_PARMS.template_parameter_id
  is 'Internal primary key of the REPCAT$_TEMPLATE_PARMS table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_PARMS.refresh_template_id
  is 'Internal primary key of the REPCAT$_REFRESH_TEMPLATES table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_PARMS.parameter_name
  is 'name of the parameter.';
comment on column SYSTEM.REPCAT$_TEMPLATE_PARMS.default_parm_value
  is 'Default value for the parameter.';
comment on column SYSTEM.REPCAT$_TEMPLATE_PARMS.prompt_string
  is 'String for use in prompting for parameter values.';
comment on column SYSTEM.REPCAT$_TEMPLATE_PARMS.user_override
  is 'User override flag.';
alter table SYSTEM.REPCAT$_TEMPLATE_PARMS
  add constraint REPCAT$_TEMPLATE_PARMS_PK primary key (TEMPLATE_PARAMETER_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_PARMS
  add constraint REPCAT$_TEMPLATE_PARMS_U1 unique (REFRESH_TEMPLATE_ID, PARAMETER_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_PARMS
  add constraint REPCAT$_TEMPLATE_PARMS_FK1 foreign key (REFRESH_TEMPLATE_ID)
  references SYSTEM.REPCAT$_REFRESH_TEMPLATES (REFRESH_TEMPLATE_ID) on delete cascade;
alter table SYSTEM.REPCAT$_TEMPLATE_PARMS
  add constraint REPCAT$_TEMPLATE_PARMS_C1
  check (user_override in ('Y','N'));

prompt
prompt Creating table REPCAT$_OBJECT_PARMS
prompt ===================================
prompt
create table SYSTEM.REPCAT$_OBJECT_PARMS
(
  template_parameter_id NUMBER not null,
  template_object_id    NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column SYSTEM.REPCAT$_OBJECT_PARMS.template_parameter_id
  is 'Primary key of template parameter.';
comment on column SYSTEM.REPCAT$_OBJECT_PARMS.template_object_id
  is 'Primary key of object using the paramter.';
create index SYSTEM.REPCAT$_OBJECT_PARMS_N2 on SYSTEM.REPCAT$_OBJECT_PARMS (TEMPLATE_OBJECT_ID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_OBJECT_PARMS
  add constraint REPCAT$_OBJECT_PARMS_PK primary key (TEMPLATE_PARAMETER_ID, TEMPLATE_OBJECT_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_OBJECT_PARMS
  add constraint REPCAT$_OBJECT_PARMS_FK1 foreign key (TEMPLATE_PARAMETER_ID)
  references SYSTEM.REPCAT$_TEMPLATE_PARMS (TEMPLATE_PARAMETER_ID);
alter table SYSTEM.REPCAT$_OBJECT_PARMS
  add constraint REPCAT$_OBJECT_PARMS_FK2 foreign key (TEMPLATE_OBJECT_ID)
  references SYSTEM.REPCAT$_TEMPLATE_OBJECTS (TEMPLATE_OBJECT_ID) on delete cascade;

prompt
prompt Creating table REPCAT$_RESOLUTION_METHOD
prompt ========================================
prompt
create table SYSTEM.REPCAT$_RESOLUTION_METHOD
(
  conflict_type_id INTEGER not null,
  method_name      VARCHAR2(80) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_RESOLUTION_METHOD
  is 'All conflict resolution methods in the database';
comment on column SYSTEM.REPCAT$_RESOLUTION_METHOD.conflict_type_id
  is 'Type of conflict';
comment on column SYSTEM.REPCAT$_RESOLUTION_METHOD.method_name
  is 'Name of the conflict resolution method';
alter table SYSTEM.REPCAT$_RESOLUTION_METHOD
  add constraint REPCAT$_RESOL_METHOD_PK primary key (CONFLICT_TYPE_ID, METHOD_NAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_RESOLUTION
prompt =================================
prompt
create table SYSTEM.REPCAT$_RESOLUTION
(
  sname              VARCHAR2(30) not null,
  oname              VARCHAR2(30) not null,
  conflict_type_id   INTEGER not null,
  reference_name     VARCHAR2(30) not null,
  sequence_no        NUMBER not null,
  method_name        VARCHAR2(80),
  function_name      VARCHAR2(92),
  priority_group     VARCHAR2(30),
  resolution_comment VARCHAR2(80)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_RESOLUTION
  is 'Description of all conflict resolutions in the database';
comment on column SYSTEM.REPCAT$_RESOLUTION.sname
  is 'Owner of replicated object';
comment on column SYSTEM.REPCAT$_RESOLUTION.oname
  is 'Name of the replicated object';
comment on column SYSTEM.REPCAT$_RESOLUTION.conflict_type_id
  is 'Type of conflict';
comment on column SYSTEM.REPCAT$_RESOLUTION.reference_name
  is 'Table name, unique constraint name, or column group name';
comment on column SYSTEM.REPCAT$_RESOLUTION.sequence_no
  is 'Ordering on resolution';
comment on column SYSTEM.REPCAT$_RESOLUTION.method_name
  is 'Name of the conflict resolution method';
comment on column SYSTEM.REPCAT$_RESOLUTION.function_name
  is 'Name of the resolution function';
comment on column SYSTEM.REPCAT$_RESOLUTION.priority_group
  is 'Name of the priority group used in conflict resolution';
comment on column SYSTEM.REPCAT$_RESOLUTION.resolution_comment
  is 'Description of the conflict resolution';
create index SYSTEM.REPCAT$_RESOLUTION_F3_IDX on SYSTEM.REPCAT$_RESOLUTION (CONFLICT_TYPE_ID, METHOD_NAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_RESOLUTION_IDX2 on SYSTEM.REPCAT$_RESOLUTION (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_RESOLUTION
  add constraint REPCAT$_RESOLUTION_PK primary key (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME, SEQUENCE_NO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_RESOLUTION
  add constraint REPCAT$_RESOLUTION_F1 foreign key (CONFLICT_TYPE_ID, METHOD_NAME)
  references SYSTEM.REPCAT$_RESOLUTION_METHOD (CONFLICT_TYPE_ID, METHOD_NAME);
alter table SYSTEM.REPCAT$_RESOLUTION
  add constraint REPCAT$_RESOLUTION_F3 foreign key (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME)
  references SYSTEM.REPCAT$_CONFLICT (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME);
alter table SYSTEM.REPCAT$_RESOLUTION
  add constraint REPCAT$_RESOLUTION_NN1
  check ("METHOD_NAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION
  add constraint REPCAT$_RESOLUTION_NN2
  check ("FUNCTION_NAME" IS NOT NULL);

prompt
prompt Creating table REPCAT$_PARAMETER_COLUMN
prompt =======================================
prompt
create table SYSTEM.REPCAT$_PARAMETER_COLUMN
(
  sname                 VARCHAR2(30) not null,
  oname                 VARCHAR2(30) not null,
  conflict_type_id      INTEGER not null,
  reference_name        VARCHAR2(30) not null,
  sequence_no           NUMBER not null,
  parameter_table_name  VARCHAR2(30) not null,
  parameter_column_name VARCHAR2(4000),
  parameter_sequence_no NUMBER not null,
  column_pos            NUMBER not null,
  attribute_sequence_no NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_PARAMETER_COLUMN
  is 'All columns used for resolving conflicts in the database';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.sname
  is 'Owner of replicated object';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.oname
  is 'Name of the replicated object';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.conflict_type_id
  is 'Type of conflict';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.reference_name
  is 'Table name, unique constraint name, or column group name';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.sequence_no
  is 'Ordering on resolution';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.parameter_table_name
  is 'Name of the table to which the parameter column belongs';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.parameter_column_name
  is 'Name of the parameter column used for resolving the conflict';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.parameter_sequence_no
  is 'Ordering on parameter column';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.column_pos
  is 'Column position of an attribute or a column';
comment on column SYSTEM.REPCAT$_PARAMETER_COLUMN.attribute_sequence_no
  is 'Sequence number for an attribute of an ADT/pkREF column or a scalar column';
create index SYSTEM.REPCAT$_PARAMETER_COLUMN_F1_I on SYSTEM.REPCAT$_PARAMETER_COLUMN (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME, SEQUENCE_NO)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_PARAMETER_COLUMN
  add constraint REPCAT$_PARAMETER_COLUMN_PK primary key (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME, SEQUENCE_NO, PARAMETER_TABLE_NAME, PARAMETER_SEQUENCE_NO, COLUMN_POS)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_PARAMETER_COLUMN
  add constraint REPCAT$_PARAMETER_COLUMN_F1 foreign key (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME, SEQUENCE_NO)
  references SYSTEM.REPCAT$_RESOLUTION (SNAME, ONAME, CONFLICT_TYPE_ID, REFERENCE_NAME, SEQUENCE_NO);

prompt
prompt Creating table REPCAT$_PRIORITY_GROUP
prompt =====================================
prompt
create table SYSTEM.REPCAT$_PRIORITY_GROUP
(
  sname             VARCHAR2(30) not null,
  priority_group    VARCHAR2(30) not null,
  data_type_id      INTEGER,
  fixed_data_length INTEGER,
  priority_comment  VARCHAR2(80)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_PRIORITY_GROUP
  is 'Information about all priority groups in the database';
comment on column SYSTEM.REPCAT$_PRIORITY_GROUP.sname
  is 'Name of the replicated object group';
comment on column SYSTEM.REPCAT$_PRIORITY_GROUP.priority_group
  is 'Name of the priority group';
comment on column SYSTEM.REPCAT$_PRIORITY_GROUP.data_type_id
  is 'Datatype of the value in the priority group';
comment on column SYSTEM.REPCAT$_PRIORITY_GROUP.fixed_data_length
  is 'Length of the value in bytes if the datatype is CHAR';
comment on column SYSTEM.REPCAT$_PRIORITY_GROUP.priority_comment
  is 'Description of the priority group';
alter table SYSTEM.REPCAT$_PRIORITY_GROUP
  add constraint REPCAT$_PRIORITY_GROUP_PK primary key (PRIORITY_GROUP, SNAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_PRIORITY_GROUP
  add constraint REPCAT$_PRIORITY_GROUP_U1 unique (SNAME, PRIORITY_GROUP, DATA_TYPE_ID, FIXED_DATA_LENGTH)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_PRIORITY_GROUP
  add constraint REPCAT$_PRIORITY_GROUP_C1
  check (data_type_id in (1, 2, 3, 4, 5, 6, 7));
alter table SYSTEM.REPCAT$_PRIORITY_GROUP
  add constraint REPCAT$_PRIORITY_GROUP_C2
  check ((data_type_id in (4, 7) and
                  fixed_data_length is not null)
              or (data_type_id in (1, 2, 3, 5, 6) and
                  fixed_data_length is null));
alter table SYSTEM.REPCAT$_PRIORITY_GROUP
  add constraint REPCAT$_PRIORITY_GROUP_NN1
  check ("DATA_TYPE_ID" IS NOT NULL);

prompt
prompt Creating table REPCAT$_PRIORITY
prompt ===============================
prompt
create table SYSTEM.REPCAT$_PRIORITY
(
  sname            VARCHAR2(30),
  priority_group   VARCHAR2(30),
  priority         NUMBER,
  raw_value        RAW(2000),
  char_value       CHAR(255),
  number_value     NUMBER,
  date_value       DATE,
  varchar2_value   VARCHAR2(4000),
  nchar_value      NCHAR(500),
  nvarchar2_value  NVARCHAR2(1000),
  large_char_value CHAR(2000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_PRIORITY
  is 'Values and their corresponding priorities in all priority groups in the database';
comment on column SYSTEM.REPCAT$_PRIORITY.sname
  is 'Name of the replicated object group';
comment on column SYSTEM.REPCAT$_PRIORITY.priority_group
  is 'Name of the priority group';
comment on column SYSTEM.REPCAT$_PRIORITY.priority
  is 'Priority of the value';
comment on column SYSTEM.REPCAT$_PRIORITY.raw_value
  is 'Raw value';
comment on column SYSTEM.REPCAT$_PRIORITY.char_value
  is 'Blank-padded character string';
comment on column SYSTEM.REPCAT$_PRIORITY.number_value
  is 'Numeric value';
comment on column SYSTEM.REPCAT$_PRIORITY.date_value
  is 'Date value';
comment on column SYSTEM.REPCAT$_PRIORITY.varchar2_value
  is 'Character string';
comment on column SYSTEM.REPCAT$_PRIORITY.nchar_value
  is 'NCHAR string';
comment on column SYSTEM.REPCAT$_PRIORITY.nvarchar2_value
  is 'NVARCHAR2 string';
comment on column SYSTEM.REPCAT$_PRIORITY.large_char_value
  is 'Blank-padded character string over 255 characters';
create index SYSTEM.REPCAT$_PRIORITY_F1_IDX on SYSTEM.REPCAT$_PRIORITY (PRIORITY_GROUP, SNAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_PRIORITY
  add constraint REPCAT$_PRIORITY_PK primary key (SNAME, PRIORITY_GROUP, PRIORITY)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_PRIORITY
  add constraint REPCAT$_PRIORITY_F1 foreign key (PRIORITY_GROUP, SNAME)
  references SYSTEM.REPCAT$_PRIORITY_GROUP (PRIORITY_GROUP, SNAME);
alter table SYSTEM.REPCAT$_PRIORITY
  add constraint REPCAT$_PRIORITY_NN1
  check ("SNAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_PRIORITY
  add constraint REPCAT$_PRIORITY_NN2
  check ("PRIORITY_GROUP" IS NOT NULL);
alter table SYSTEM.REPCAT$_PRIORITY
  add constraint REPCAT$_PRIORITY_NN3
  check ("PRIORITY" IS NOT NULL);

prompt
prompt Creating table REPCAT$_REPCOLUMN
prompt ================================
prompt
create table SYSTEM.REPCAT$_REPCOLUMN
(
  sname       VARCHAR2(30) not null,
  oname       VARCHAR2(30) not null,
  type        INTEGER not null,
  cname       VARCHAR2(30) not null,
  lcname      VARCHAR2(4000),
  toid        RAW(16),
  version#    NUMBER,
  hashcode    RAW(17),
  ctype_name  VARCHAR2(30),
  ctype_owner VARCHAR2(30),
  id          NUMBER,
  pos         NUMBER,
  top         VARCHAR2(30),
  flag        RAW(2) default '0000',
  ctype       NUMBER,
  length      NUMBER,
  precision#  NUMBER,
  scale       NUMBER,
  null$       NUMBER,
  charsetid   NUMBER,
  charsetform NUMBER,
  property    RAW(4) default '00000000',
  clength     NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REPCOLUMN
  is 'Replicated columns for a table sorted alphabetically in ascending order';
comment on column SYSTEM.REPCAT$_REPCOLUMN.sname
  is 'Name of the object owner';
comment on column SYSTEM.REPCAT$_REPCOLUMN.oname
  is 'Name of the object';
comment on column SYSTEM.REPCAT$_REPCOLUMN.type
  is 'Type of the object';
comment on column SYSTEM.REPCAT$_REPCOLUMN.cname
  is 'Column name';
comment on column SYSTEM.REPCAT$_REPCOLUMN.lcname
  is 'Long column name';
comment on column SYSTEM.REPCAT$_REPCOLUMN.toid
  is 'Type object identifier of a user-defined type';
comment on column SYSTEM.REPCAT$_REPCOLUMN.version#
  is 'Version# of a column of user-defined type';
comment on column SYSTEM.REPCAT$_REPCOLUMN.hashcode
  is 'Hashcode of a column of user-defined type';
comment on column SYSTEM.REPCAT$_REPCOLUMN.id
  is 'Column ID';
comment on column SYSTEM.REPCAT$_REPCOLUMN.pos
  is 'Ordering of column used as IN parameter in the replication procedures';
comment on column SYSTEM.REPCAT$_REPCOLUMN.top
  is 'Top column name for an attribute';
comment on column SYSTEM.REPCAT$_REPCOLUMN.flag
  is 'Replication information about column';
comment on column SYSTEM.REPCAT$_REPCOLUMN.ctype
  is 'Type of the column';
comment on column SYSTEM.REPCAT$_REPCOLUMN.length
  is 'Length of the column in bytes';
comment on column SYSTEM.REPCAT$_REPCOLUMN.precision#
  is 'Length: decimal digits (NUMBER) or binary digits (FLOAT)';
comment on column SYSTEM.REPCAT$_REPCOLUMN.scale
  is 'Digits to right of decimal point in a number';
comment on column SYSTEM.REPCAT$_REPCOLUMN.null$
  is 'Does column allow NULL values?';
comment on column SYSTEM.REPCAT$_REPCOLUMN.charsetid
  is 'Character set identifier';
comment on column SYSTEM.REPCAT$_REPCOLUMN.charsetform
  is 'Character set form';
comment on column SYSTEM.REPCAT$_REPCOLUMN.clength
  is 'The maximum length of the column in characters';
create index SYSTEM.REPCAT$_REPCOLUMN_FK_IDX on SYSTEM.REPCAT$_REPCOLUMN (SNAME, ONAME, TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPCOLUMN
  add constraint REPCAT$_REPCOLUMN_PK primary key (SNAME, ONAME, TYPE, CNAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPCOLUMN
  add constraint REPCAT$_REPCOLUMN_FK foreign key (SNAME, ONAME, TYPE)
  references SYSTEM.REPCAT$_REPOBJECT (SNAME, ONAME, TYPE) on delete cascade;
alter table SYSTEM.REPCAT$_REPCOLUMN
  add constraint REPCAT$_REPCOLUMN_VERSION
  check (version# >= 0 AND version# < 65536);

prompt
prompt Creating table REPCAT$_REPGROUP_PRIVS
prompt =====================================
prompt
create table SYSTEM.REPCAT$_REPGROUP_PRIVS
(
  userid      NUMBER,
  username    VARCHAR2(30) not null,
  gowner      VARCHAR2(30),
  gname       VARCHAR2(30),
  global_flag NUMBER not null,
  created     DATE not null,
  privilege   NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REPGROUP_PRIVS
  is 'Information about users who are registered for object group privileges';
comment on column SYSTEM.REPCAT$_REPGROUP_PRIVS.userid
  is 'OBSOLETE COLUMN: Identifying number of the user';
comment on column SYSTEM.REPCAT$_REPGROUP_PRIVS.username
  is 'Identifying name of the registered user';
comment on column SYSTEM.REPCAT$_REPGROUP_PRIVS.gowner
  is 'Owner of the replicated object group';
comment on column SYSTEM.REPCAT$_REPGROUP_PRIVS.gname
  is 'Name of the replicated object group';
comment on column SYSTEM.REPCAT$_REPGROUP_PRIVS.global_flag
  is '1 if gname is NULL, 0 otherwise';
comment on column SYSTEM.REPCAT$_REPGROUP_PRIVS.created
  is 'Registration date';
comment on column SYSTEM.REPCAT$_REPGROUP_PRIVS.privilege
  is 'Registered privileges';
create index SYSTEM.REPCAT$_REPGROUP_PRIVS_FK_IDX on SYSTEM.REPCAT$_REPGROUP_PRIVS (GNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_REPGROUP_PRIVS_N1 on SYSTEM.REPCAT$_REPGROUP_PRIVS (GLOBAL_FLAG, USERNAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPGROUP_PRIVS
  add constraint REPCAT$_REPGROUP_PRIVS_UK unique (USERNAME, GNAME, GOWNER)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPGROUP_PRIVS
  add constraint REPCAT$_REPGROUP_PRIVS_FK foreign key (GNAME, GOWNER)
  references SYSTEM.REPCAT$_REPCAT (SNAME, GOWNER) on delete cascade;

prompt
prompt Creating table REPCAT$_REPPROP
prompt ==============================
prompt
create table SYSTEM.REPCAT$_REPPROP
(
  sname             VARCHAR2(30) not null,
  oname             VARCHAR2(30) not null,
  type              INTEGER not null,
  dblink            VARCHAR2(128) not null,
  how               INTEGER,
  propagate_comment VARCHAR2(80),
  delivery_order    NUMBER,
  recipient_key     NUMBER,
  extension_id      RAW(16) default '00'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REPPROP
  is 'Propagation information about replicated objects';
comment on column SYSTEM.REPCAT$_REPPROP.sname
  is 'Name of the object owner';
comment on column SYSTEM.REPCAT$_REPPROP.oname
  is 'Name of the object';
comment on column SYSTEM.REPCAT$_REPPROP.type
  is 'Type of the object';
comment on column SYSTEM.REPCAT$_REPPROP.dblink
  is 'Destination database for propagation';
comment on column SYSTEM.REPCAT$_REPPROP.how
  is 'Propagation choice for the destination database';
comment on column SYSTEM.REPCAT$_REPPROP.propagate_comment
  is 'Description of the propagation choice';
comment on column SYSTEM.REPCAT$_REPPROP.delivery_order
  is 'Value of delivery order when the master was added';
comment on column SYSTEM.REPCAT$_REPPROP.recipient_key
  is 'Recipient key for sname and oname, used in joining with def$_aqcall';
comment on column SYSTEM.REPCAT$_REPPROP.extension_id
  is 'Identifier of any active extension request';
create index SYSTEM.REPCAT$_REPPROP_DBLINK_HOW on SYSTEM.REPCAT$_REPPROP (DBLINK, HOW, EXTENSION_ID, RECIPIENT_KEY)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_REPPROP_KEY_INDEX on SYSTEM.REPCAT$_REPPROP (RECIPIENT_KEY)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_REPPROP_PRNT2_IDX on SYSTEM.REPCAT$_REPPROP (SNAME, DBLINK)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_REPPROP_PRNT_IDX on SYSTEM.REPCAT$_REPPROP (SNAME, ONAME, TYPE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPPROP
  add constraint REPCAT$_REPPROP_PRIMARY primary key (SNAME, ONAME, TYPE, DBLINK)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPPROP
  add constraint REPCAT$_REPPROP_PRNT foreign key (SNAME, ONAME, TYPE)
  references SYSTEM.REPCAT$_REPOBJECT (SNAME, ONAME, TYPE) on delete cascade;
alter table SYSTEM.REPCAT$_REPPROP
  add constraint REPCAT$_REPPROP_HOW
  check (how IN (0, 1, 2, 3));

prompt
prompt Creating table REPCAT$_REPSCHEMA
prompt ================================
prompt
create table SYSTEM.REPCAT$_REPSCHEMA
(
  gowner         VARCHAR2(30) default 'PUBLIC' not null,
  sname          VARCHAR2(30) not null,
  dblink         VARCHAR2(128) not null,
  masterdef      VARCHAR2(1),
  snapmaster     VARCHAR2(1),
  master_comment VARCHAR2(80),
  master         VARCHAR2(1),
  prop_updates   NUMBER default 0,
  my_dblink      VARCHAR2(1),
  extension_id   RAW(16) default '00'
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_REPSCHEMA
  is 'N-way replication information';
comment on column SYSTEM.REPCAT$_REPSCHEMA.gowner
  is 'Owner of the replicated object group';
comment on column SYSTEM.REPCAT$_REPSCHEMA.sname
  is 'Name of the replicated object group';
comment on column SYSTEM.REPCAT$_REPSCHEMA.dblink
  is 'A database site replicating the object group';
comment on column SYSTEM.REPCAT$_REPSCHEMA.masterdef
  is 'Is the database the master definition site for the replicated object group';
comment on column SYSTEM.REPCAT$_REPSCHEMA.snapmaster
  is 'For a snapshot site, is this the current refresh_master';
comment on column SYSTEM.REPCAT$_REPSCHEMA.master_comment
  is 'Description of the database site';
comment on column SYSTEM.REPCAT$_REPSCHEMA.master
  is 'Redundant information from repcat$_repcat.master';
comment on column SYSTEM.REPCAT$_REPSCHEMA.prop_updates
  is 'Number of requested updates for master in repcat$_repprop';
comment on column SYSTEM.REPCAT$_REPSCHEMA.my_dblink
  is 'A sanity check after import: is this master the current site';
comment on column SYSTEM.REPCAT$_REPSCHEMA.extension_id
  is 'Dummy column for foreign key';
create index SYSTEM.REPCAT$_REPSCHEMA_DEST_IDX on SYSTEM.REPCAT$_REPSCHEMA (DBLINK, EXTENSION_ID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_REPSCHEMA_PRNT_IDX on SYSTEM.REPCAT$_REPSCHEMA (SNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPSCHEMA
  add constraint REPCAT$_REPSCHEMA_PRIMARY primary key (SNAME, DBLINK, GOWNER)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_REPSCHEMA
  add constraint REPCAT$_REPSCHEMA_DEST foreign key (DBLINK, EXTENSION_ID)
  references SYSTEM.DEF$_DESTINATION (DBLINK, CATCHUP);
alter table SYSTEM.REPCAT$_REPSCHEMA
  add constraint REPCAT$_REPSCHEMA_PRNT foreign key (SNAME, GOWNER)
  references SYSTEM.REPCAT$_REPCAT (SNAME, GOWNER) on delete cascade;

prompt
prompt Creating table REPCAT$_RESOLUTION_STATISTICS
prompt ============================================
prompt
create table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
(
  sname             VARCHAR2(30),
  oname             VARCHAR2(30),
  conflict_type_id  INTEGER,
  reference_name    VARCHAR2(30),
  method_name       VARCHAR2(80),
  function_name     VARCHAR2(92),
  priority_group    VARCHAR2(30),
  resolved_date     DATE,
  primary_key_value VARCHAR2(2000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  is 'Statistics for conflict resolutions for all replicated tables in the database';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.sname
  is 'Owner of replicated object';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.oname
  is 'Name of the replicated object';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.conflict_type_id
  is 'Type of conflict';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.reference_name
  is 'Table name, unique constraint name, or column group name';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.method_name
  is 'Name of the conflict resolution method';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.function_name
  is 'Name of the resolution function';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.priority_group
  is 'Name of the priority group used in conflict resolution';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.resolved_date
  is 'Timestamp for the resolution of the conflict';
comment on column SYSTEM.REPCAT$_RESOLUTION_STATISTICS.primary_key_value
  is 'Primary key of the replicated row (character data)';
create index SYSTEM.REPCAT$_RESOLUTION_STATS_N1 on SYSTEM.REPCAT$_RESOLUTION_STATISTICS (SNAME, ONAME, RESOLVED_DATE, CONFLICT_TYPE_ID, REFERENCE_NAME, METHOD_NAME, FUNCTION_NAME, PRIORITY_GROUP)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN1
  check ("SNAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN2
  check ("ONAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN3
  check ("CONFLICT_TYPE_ID" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN4
  check ("REFERENCE_NAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN5
  check ("METHOD_NAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN6
  check ("FUNCTION_NAME" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN7
  check ("RESOLVED_DATE" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOLUTION_STATISTICS
  add constraint REPCAT$_RESOLUTION_STATS_NN8
  check ("PRIMARY_KEY_VALUE" IS NOT NULL);

prompt
prompt Creating table REPCAT$_RESOL_STATS_CONTROL
prompt ==========================================
prompt
create table SYSTEM.REPCAT$_RESOL_STATS_CONTROL
(
  sname                 VARCHAR2(30) not null,
  oname                 VARCHAR2(30) not null,
  created               DATE,
  status                INTEGER,
  status_update_date    DATE,
  purged_date           DATE,
  last_purge_start_date DATE,
  last_purge_end_date   DATE
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_RESOL_STATS_CONTROL
  is 'Information about statistics collection for conflict resolutions for all replicated tables in the database';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.sname
  is 'Owner of replicated object';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.oname
  is 'Name of the replicated object';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.created
  is 'Timestamp for which statistics collection was first started';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.status
  is 'Status of statistics collection: ACTIVE, CANCELLED';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.status_update_date
  is 'Timestamp for which the status was last updated';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.purged_date
  is 'Timestamp for the last purge of statistics data';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.last_purge_start_date
  is 'The last start date of the statistics purging date range';
comment on column SYSTEM.REPCAT$_RESOL_STATS_CONTROL.last_purge_end_date
  is 'The last end date of the statistics purging date range';
alter table SYSTEM.REPCAT$_RESOL_STATS_CONTROL
  add constraint REPCAT$_RESOL_STATS_CTRL_PK primary key (SNAME, ONAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_RESOL_STATS_CONTROL
  add constraint REPCAT$_RESOL_STATS_CTRL_NN1
  check ("CREATED" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOL_STATS_CONTROL
  add constraint REPCAT$_RESOL_STATS_CTRL_NN2
  check ("STATUS" IS NOT NULL);
alter table SYSTEM.REPCAT$_RESOL_STATS_CONTROL
  add constraint REPCAT$_RESOL_STATS_CTRL_NN3
  check ("STATUS_UPDATE_DATE" IS NOT NULL);

prompt
prompt Creating table REPCAT$_RUNTIME_PARMS
prompt ====================================
prompt
create table SYSTEM.REPCAT$_RUNTIME_PARMS
(
  runtime_parm_id NUMBER,
  parameter_name  VARCHAR2(30),
  parm_value      CLOB
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column SYSTEM.REPCAT$_RUNTIME_PARMS.runtime_parm_id
  is 'Primary key of the parameter values table.';
comment on column SYSTEM.REPCAT$_RUNTIME_PARMS.parameter_name
  is 'Name of the parameter.';
comment on column SYSTEM.REPCAT$_RUNTIME_PARMS.parm_value
  is 'Parameter value.';
create unique index SYSTEM.REPCAT$_RUNTIME_PARMS_PK on SYSTEM.REPCAT$_RUNTIME_PARMS (RUNTIME_PARM_ID, PARAMETER_NAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_SITES_NEW
prompt ================================
prompt
create table SYSTEM.REPCAT$_SITES_NEW
(
  extension_id       RAW(16) not null,
  gowner             VARCHAR2(30) not null,
  gname              VARCHAR2(30) not null,
  dblink             VARCHAR2(128) not null,
  full_instantiation VARCHAR2(1),
  master_status      NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_SITES_NEW
  is 'Information about new masters for replication extension';
comment on column SYSTEM.REPCAT$_SITES_NEW.extension_id
  is 'Globally unique identifier for replication extension';
comment on column SYSTEM.REPCAT$_SITES_NEW.gowner
  is 'Owner of the object group';
comment on column SYSTEM.REPCAT$_SITES_NEW.gname
  is 'Name of the replicated object group';
comment on column SYSTEM.REPCAT$_SITES_NEW.dblink
  is 'A database site that will replicate the object group';
comment on column SYSTEM.REPCAT$_SITES_NEW.full_instantiation
  is 'Y if the database uses full-database export or change-based recovery';
comment on column SYSTEM.REPCAT$_SITES_NEW.master_status
  is 'Instantiation status of the new master';
create index SYSTEM.REPCAT$_SITES_NEW_FK1_IDX on SYSTEM.REPCAT$_SITES_NEW (EXTENSION_ID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_SITES_NEW_FK2_IDX on SYSTEM.REPCAT$_SITES_NEW (GNAME, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_SITES_NEW
  add constraint REPCAT$_SITES_NEW_PK primary key (EXTENSION_ID, GOWNER, GNAME, DBLINK)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_SITES_NEW
  add constraint REPCAT$_SITES_NEW_FK1 foreign key (EXTENSION_ID)
  references SYSTEM.REPCAT$_EXTENSION (EXTENSION_ID) on delete cascade;
alter table SYSTEM.REPCAT$_SITES_NEW
  add constraint REPCAT$_SITES_NEW_FK2 foreign key (GNAME, GOWNER)
  references SYSTEM.REPCAT$_REPCAT (SNAME, GOWNER) on delete cascade;
alter table SYSTEM.REPCAT$_SITES_NEW
  add constraint REPCAT$_SITES_NEW_FULL_INST
  check (full_instantiation IN ('Y', 'N'));

prompt
prompt Creating table REPCAT$_TEMPLATE_SITES
prompt =====================================
prompt
create table SYSTEM.REPCAT$_TEMPLATE_SITES
(
  template_site_id      NUMBER not null,
  refresh_template_name VARCHAR2(30) not null,
  refresh_group_name    VARCHAR2(30),
  template_owner        VARCHAR2(30),
  user_name             VARCHAR2(30) not null,
  site_name             VARCHAR2(128),
  repapi_site_id        NUMBER,
  status                NUMBER not null,
  refresh_template_id   NUMBER,
  user_id               NUMBER,
  instantiation_date    DATE
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.template_site_id
  is 'Internal primary key of the REPCAT$_TEMPLATE_SITES table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.refresh_template_name
  is 'Name of the refresh group template.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.refresh_group_name
  is 'Name of the refresh group to create during instantiation.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.template_owner
  is 'Owner of the refresh group template.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.user_name
  is 'Database user name.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.site_name
  is 'Name of the site that has instantiated the template.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.repapi_site_id
  is 'Name of the site that has instantiated the template.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.status
  is 'Obsolete - do not use.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.refresh_template_id
  is 'Obsolete - do not use.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.user_id
  is 'Obsolete - do not use.';
comment on column SYSTEM.REPCAT$_TEMPLATE_SITES.instantiation_date
  is 'Date template was instantiated.';
alter table SYSTEM.REPCAT$_TEMPLATE_SITES
  add constraint REPCAT$_TEMPLATE_SITES_PK primary key (TEMPLATE_SITE_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_SITES
  add constraint REPCAT$_TEMPLATE_SITES_U1 unique (REFRESH_TEMPLATE_NAME, USER_NAME, SITE_NAME, REPAPI_SITE_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_SITES
  add constraint REPCAT$_TEMPLATE_SITES_C1
  check (status in (-100,-1,0,1));
alter table SYSTEM.REPCAT$_TEMPLATE_SITES
  add constraint REPCAT$_TEMPLATE_SITES_C2
  check ((site_name is not null and repapi_site_id is null) or
   (site_name is null and repapi_site_id is not null));

prompt
prompt Creating table REPCAT$_SITE_OBJECTS
prompt ===================================
prompt
create table SYSTEM.REPCAT$_SITE_OBJECTS
(
  template_site_id NUMBER not null,
  sname            VARCHAR2(30),
  oname            VARCHAR2(30) not null,
  object_type_id   NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_SITE_OBJECTS
  is 'Table for maintaining database objects deployed at a site.';
comment on column SYSTEM.REPCAT$_SITE_OBJECTS.template_site_id
  is 'Internal primary key of the template sites table.';
comment on column SYSTEM.REPCAT$_SITE_OBJECTS.sname
  is 'Schema containing the deployed database object.';
comment on column SYSTEM.REPCAT$_SITE_OBJECTS.oname
  is 'Name of the deployed database object.';
comment on column SYSTEM.REPCAT$_SITE_OBJECTS.object_type_id
  is 'Internal ID of the object type of the deployed database object.';
create index SYSTEM.REPCAT$_SITE_OBJECTS_N1 on SYSTEM.REPCAT$_SITE_OBJECTS (TEMPLATE_SITE_ID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_SITE_OBJECTS
  add constraint REPCAT$_SITE_OBJECTS_U1 unique (TEMPLATE_SITE_ID, ONAME, OBJECT_TYPE_ID, SNAME)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_SITE_OBJECTS
  add constraint REPCAT$_SITE_OBJECTS_FK1 foreign key (OBJECT_TYPE_ID)
  references SYSTEM.REPCAT$_OBJECT_TYPES (OBJECT_TYPE_ID);
alter table SYSTEM.REPCAT$_SITE_OBJECTS
  add constraint REPCAT$_SITE_OBJECT_FK2 foreign key (TEMPLATE_SITE_ID)
  references SYSTEM.REPCAT$_TEMPLATE_SITES (TEMPLATE_SITE_ID) on delete cascade;

prompt
prompt Creating table REPCAT$_SNAPGROUP
prompt ================================
prompt
create table SYSTEM.REPCAT$_SNAPGROUP
(
  gowner        VARCHAR2(30) default 'PUBLIC',
  gname         VARCHAR2(30),
  dblink        VARCHAR2(128),
  group_comment VARCHAR2(80),
  rep_type      NUMBER,
  flavor_id     NUMBER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_SNAPGROUP
  is 'Snapshot repgroup registration information';
comment on column SYSTEM.REPCAT$_SNAPGROUP.gowner
  is 'Owner of the snapshot repgroup';
comment on column SYSTEM.REPCAT$_SNAPGROUP.gname
  is 'Name of the snapshot repgroup';
comment on column SYSTEM.REPCAT$_SNAPGROUP.dblink
  is 'Database site of the snapshot repgroup';
comment on column SYSTEM.REPCAT$_SNAPGROUP.group_comment
  is 'Description of the snapshot repgroup';
comment on column SYSTEM.REPCAT$_SNAPGROUP.rep_type
  is 'Identifier of flavor at snapshot';
create unique index SYSTEM.I_REPCAT$_SNAPGROUP1 on SYSTEM.REPCAT$_SNAPGROUP (GNAME, DBLINK, GOWNER)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_TEMPLATE_REFGROUPS
prompt =========================================
prompt
create table SYSTEM.REPCAT$_TEMPLATE_REFGROUPS
(
  refresh_group_id    NUMBER not null,
  refresh_group_name  VARCHAR2(30) not null,
  refresh_template_id NUMBER not null,
  rollback_seg        VARCHAR2(30),
  start_date          VARCHAR2(200),
  interval            VARCHAR2(200)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_TEMPLATE_REFGROUPS
  is 'Table for maintaining refresh group information for template.';
comment on column SYSTEM.REPCAT$_TEMPLATE_REFGROUPS.refresh_group_id
  is 'Internal primary key of the refresh groups table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_REFGROUPS.refresh_group_name
  is 'Name of the refresh group';
comment on column SYSTEM.REPCAT$_TEMPLATE_REFGROUPS.refresh_template_id
  is 'Primary key of the template containing the refresh group.';
comment on column SYSTEM.REPCAT$_TEMPLATE_REFGROUPS.rollback_seg
  is 'Name of the rollback segment to use during refresh.';
comment on column SYSTEM.REPCAT$_TEMPLATE_REFGROUPS.start_date
  is 'Refresh start date.';
comment on column SYSTEM.REPCAT$_TEMPLATE_REFGROUPS.interval
  is 'Refresh interval.';
create index SYSTEM.REPCAT$_TEMPLATE_REFGROUPS_N1 on SYSTEM.REPCAT$_TEMPLATE_REFGROUPS (REFRESH_GROUP_NAME)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index SYSTEM.REPCAT$_TEMPLATE_REFGROUPS_N2 on SYSTEM.REPCAT$_TEMPLATE_REFGROUPS (REFRESH_TEMPLATE_ID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_REFGROUPS
  add constraint REPCAT$_TEMPLATE_REFGROUPS_PK primary key (REFRESH_GROUP_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_REFGROUPS
  add constraint REPCAT$_TEMPLATE_REFGROUPS_FK1 foreign key (REFRESH_TEMPLATE_ID)
  references SYSTEM.REPCAT$_REFRESH_TEMPLATES (REFRESH_TEMPLATE_ID) on delete cascade;

prompt
prompt Creating table REPCAT$_TEMPLATE_TARGETS
prompt =======================================
prompt
create table SYSTEM.REPCAT$_TEMPLATE_TARGETS
(
  template_target_id NUMBER not null,
  target_database    VARCHAR2(128) not null,
  target_comment     VARCHAR2(2000),
  connect_string     VARCHAR2(4000),
  spare1             VARCHAR2(4000)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table SYSTEM.REPCAT$_TEMPLATE_TARGETS
  is 'Internal table for tracking potential target databases for templates.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TARGETS.template_target_id
  is 'Internal primary key of the template targets table.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TARGETS.target_database
  is 'Global identifier of the target database.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TARGETS.target_comment
  is 'Comment on the target database.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TARGETS.connect_string
  is 'The connection descriptor used to connect to the target database.';
comment on column SYSTEM.REPCAT$_TEMPLATE_TARGETS.spare1
  is 'The spare column';
create unique index SYSTEM.REPCAT$_TEMPLATE_TARGETS_U1 on SYSTEM.REPCAT$_TEMPLATE_TARGETS (TARGET_DATABASE)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_TEMPLATE_TARGETS
  add constraint TEMPLATE$_TARGETS_PK primary key (TEMPLATE_TARGET_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REPCAT$_USER_AUTHORIZATIONS
prompt ==========================================
prompt
create table SYSTEM.REPCAT$_USER_AUTHORIZATIONS
(
  user_authorization_id NUMBER not null,
  user_id               NUMBER not null,
  refresh_template_id   NUMBER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column SYSTEM.REPCAT$_USER_AUTHORIZATIONS.user_authorization_id
  is 'Internal primary key of the REPCAT$_USER_AUTHORIZATIONS table.';
comment on column SYSTEM.REPCAT$_USER_AUTHORIZATIONS.user_id
  is 'Database user id.';
comment on column SYSTEM.REPCAT$_USER_AUTHORIZATIONS.refresh_template_id
  is 'Internal primary key of the REPCAT$_REFRESH_TEMPLATES table.';
create index SYSTEM.REPCAT$_USER_AUTHORIZATIONS_N1 on SYSTEM.REPCAT$_USER_AUTHORIZATIONS (REFRESH_TEMPLATE_ID)
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_USER_AUTHORIZATIONS
  add constraint REPCAT$_USER_AUTHORIZATIONS_PK primary key (USER_AUTHORIZATION_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_USER_AUTHORIZATIONS
  add constraint REPCAT$_USER_AUTHORIZATIONS_U1 unique (USER_ID, REFRESH_TEMPLATE_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_USER_AUTHORIZATIONS
  add constraint REPCAT$_USER_AUTHORIZATION_FK2 foreign key (REFRESH_TEMPLATE_ID)
  references SYSTEM.REPCAT$_REFRESH_TEMPLATES (REFRESH_TEMPLATE_ID) on delete cascade;

prompt
prompt Creating table REPCAT$_USER_PARM_VALUES
prompt =======================================
prompt
create table SYSTEM.REPCAT$_USER_PARM_VALUES
(
  user_parameter_id     NUMBER not null,
  template_parameter_id NUMBER not null,
  user_id               NUMBER not null,
  parm_value            CLOB
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column SYSTEM.REPCAT$_USER_PARM_VALUES.user_parameter_id
  is 'Internal primary key of the REPCAT$_USER_PARM_VALUES table.';
comment on column SYSTEM.REPCAT$_USER_PARM_VALUES.template_parameter_id
  is 'Internal primary key of the REPCAT$_TEMPLATE_PARMS table.';
comment on column SYSTEM.REPCAT$_USER_PARM_VALUES.user_id
  is 'Database user id.';
comment on column SYSTEM.REPCAT$_USER_PARM_VALUES.parm_value
  is 'Value of the parameter for this user.';
alter table SYSTEM.REPCAT$_USER_PARM_VALUES
  add constraint REPCAT$_USER_PARM_VALUES_PK primary key (USER_PARAMETER_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_USER_PARM_VALUES
  add constraint REPCAT$_USER_PARM_VALUES_U1 unique (TEMPLATE_PARAMETER_ID, USER_ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.REPCAT$_USER_PARM_VALUES
  add constraint REPCAT$_USER_PARM_VALUES_FK1 foreign key (TEMPLATE_PARAMETER_ID)
  references SYSTEM.REPCAT$_TEMPLATE_PARMS (TEMPLATE_PARAMETER_ID) on delete cascade;

prompt
prompt Creating table ROLE
prompt ===================
prompt
create table SYSTEM.ROLE
(
  id       VARCHAR2(32) default SYS_GUID() not null,
  rolename VARCHAR2(50),
  roledesc VARCHAR2(50)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ROLE
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROLE_PERMISSION
prompt ==============================
prompt
create table SYSTEM.ROLE_PERMISSION
(
  permissionid VARCHAR2(32) not null,
  roleid       VARCHAR2(32) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ROLE_PERMISSION
  add primary key (PERMISSIONID, ROLEID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.ROLE_PERMISSION
  add foreign key (PERMISSIONID)
  references SYSTEM.PERMISSION (ID);
alter table SYSTEM.ROLE_PERMISSION
  add foreign key (ROLEID)
  references SYSTEM.ROLE (ID);

prompt
prompt Creating table SQLPLUS_PRODUCT_PROFILE
prompt ======================================
prompt
create table SYSTEM.SQLPLUS_PRODUCT_PROFILE
(
  product       VARCHAR2(30) not null,
  userid        VARCHAR2(30),
  attribute     VARCHAR2(240),
  scope         VARCHAR2(240),
  numeric_value NUMBER(15,2),
  char_value    VARCHAR2(240),
  date_value    DATE,
  long_value    LONG
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table USERS
prompt ====================
prompt
create table SYSTEM.USERS
(
  id       VARCHAR2(32) default SYS_GUID() not null,
  email    VARCHAR2(50) not null,
  username VARCHAR2(50),
  password VARCHAR2(100),
  phonenum VARCHAR2(20),
  status   INTEGER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.USERS
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.USERS
  add unique (EMAIL)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table USERS_ROLE
prompt =========================
prompt
create table SYSTEM.USERS_ROLE
(
  userid VARCHAR2(32) not null,
  roleid VARCHAR2(32) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.USERS_ROLE
  add primary key (USERID, ROLEID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table SYSTEM.USERS_ROLE
  add foreign key (USERID)
  references SYSTEM.USERS (ID);
alter table SYSTEM.USERS_ROLE
  add foreign key (ROLEID)
  references SYSTEM.ROLE (ID);

prompt
prompt Creating sequence LOGMNR_EVOLVE_SEQ$
prompt ====================================
prompt
create sequence SYSTEM.LOGMNR_EVOLVE_SEQ$
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20
order;

prompt
prompt Creating sequence LOGMNR_SEQ$
prompt =============================
prompt
create sequence SYSTEM.LOGMNR_SEQ$
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20
order;

prompt
prompt Creating sequence LOGMNR_UIDS$
prompt ==============================
prompt
create sequence SYSTEM.LOGMNR_UIDS$
minvalue 1
maxvalue 999999999999999999999999999
start with 100
increment by 1
cache 20
order;

prompt
prompt Creating sequence MVIEW$_ADVSEQ_GENERIC
prompt =======================================
prompt
create sequence SYSTEM.MVIEW$_ADVSEQ_GENERIC
minvalue 1
maxvalue 4294967295
start with 1
increment by 1
cache 50;

prompt
prompt Creating sequence MVIEW$_ADVSEQ_ID
prompt ==================================
prompt
create sequence SYSTEM.MVIEW$_ADVSEQ_ID
minvalue 1
maxvalue 4294967295
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_EXCEPTIONS_S
prompt ======================================
prompt
create sequence SYSTEM.REPCAT$_EXCEPTIONS_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_FLAVORS_S
prompt ===================================
prompt
create sequence SYSTEM.REPCAT$_FLAVORS_S
minvalue -2147483647
maxvalue 2147483647
start with 1
increment by 1
nocache;

prompt
prompt Creating sequence REPCAT$_FLAVOR_NAME_S
prompt =======================================
prompt
create sequence SYSTEM.REPCAT$_FLAVOR_NAME_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
nocache;

prompt
prompt Creating sequence REPCAT$_REFRESH_TEMPLATES_S
prompt =============================================
prompt
create sequence SYSTEM.REPCAT$_REFRESH_TEMPLATES_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_REPPROP_KEY
prompt =====================================
prompt
create sequence SYSTEM.REPCAT$_REPPROP_KEY
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_RUNTIME_PARMS_S
prompt =========================================
prompt
create sequence SYSTEM.REPCAT$_RUNTIME_PARMS_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_TEMPLATE_OBJECTS_S
prompt ============================================
prompt
create sequence SYSTEM.REPCAT$_TEMPLATE_OBJECTS_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_TEMPLATE_PARMS_S
prompt ==========================================
prompt
create sequence SYSTEM.REPCAT$_TEMPLATE_PARMS_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_TEMPLATE_REFGROUPS_S
prompt ==============================================
prompt
create sequence SYSTEM.REPCAT$_TEMPLATE_REFGROUPS_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_TEMPLATE_SITES_S
prompt ==========================================
prompt
create sequence SYSTEM.REPCAT$_TEMPLATE_SITES_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_TEMP_OUTPUT_S
prompt =======================================
prompt
create sequence SYSTEM.REPCAT$_TEMP_OUTPUT_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_USER_AUTHORIZATIONS_S
prompt ===============================================
prompt
create sequence SYSTEM.REPCAT$_USER_AUTHORIZATIONS_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT$_USER_PARM_VALUES_S
prompt ============================================
prompt
create sequence SYSTEM.REPCAT$_USER_PARM_VALUES_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence REPCAT_LOG_SEQUENCE
prompt =====================================
prompt
create sequence SYSTEM.REPCAT_LOG_SEQUENCE
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TEMPLATE$_TARGETS_S
prompt =====================================
prompt
create sequence SYSTEM.TEMPLATE$_TARGETS_S
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating synonym CATALOG
prompt ========================
prompt
create or replace synonym SYSTEM.CATALOG
  for SYS.CATALOG;

prompt
prompt Creating synonym COL
prompt ====================
prompt
create or replace synonym SYSTEM.COL
  for SYS.COL;

prompt
prompt Creating synonym PRODUCT_USER_PROFILE
prompt =====================================
prompt
create or replace synonym SYSTEM.PRODUCT_USER_PROFILE
  for SYSTEM.SQLPLUS_PRODUCT_PROFILE;

prompt
prompt Creating synonym PUBLICSYN
prompt ==========================
prompt
create or replace synonym SYSTEM.PUBLICSYN
  for SYS.PUBLICSYN;

prompt
prompt Creating synonym SYSCATALOG
prompt ===========================
prompt
create or replace synonym SYSTEM.SYSCATALOG
  for SYS.SYSCATALOG;

prompt
prompt Creating synonym SYSFILES
prompt =========================
prompt
create or replace synonym SYSTEM.SYSFILES
  for SYS.SYSFILES;

prompt
prompt Creating synonym TAB
prompt ====================
prompt
create or replace synonym SYSTEM.TAB
  for SYS.TAB;

prompt
prompt Creating synonym TABQUOTAS
prompt ==========================
prompt
create or replace synonym SYSTEM.TABQUOTAS
  for SYS.TABQUOTAS;

prompt
prompt Creating view AQ$DEF$_AQCALL
prompt ============================
prompt
CREATE OR REPLACE FORCE VIEW SYSTEM.AQ$DEF$_AQCALL AS
SELECT q_name QUEUE, msgid MSG_ID, corrid CORR_ID, priority MSG_PRIORITY, decode(state, 0,   'READY',
                                1,   'WAIT',
                                2,   'PROCESSED',
                                3,   'EXPIRED',
                                10,  'BUFFERED_EXPIRED') MSG_STATE, cast(FROM_TZ(delay, '-07:00')
                  at time zone sessiontimezone as date) DELAY, delay DELAY_TIMESTAMP, expiration, cast(FROM_TZ(enq_time, '-07:00')
                  at time zone sessiontimezone as date) ENQ_TIME, cast(FROM_TZ(enq_time, '-07:00')
                  at time zone sessiontimezone as timestamp) 
                  ENQ_TIMESTAMP, enq_uid ENQ_USER_ID, enq_tid ENQ_TXN_ID, cast(FROM_TZ(deq_time, '-07:00')
                  at time zone sessiontimezone as date) DEQ_TIME, cast(FROM_TZ(deq_time, '-07:00')
                  at time zone sessiontimezone as timestamp) 
                  DEQ_TIMESTAMP, deq_uid DEQ_USER_ID, deq_tid DEQ_TXN_ID, retry_count,  decode (state, 0, exception_qschema, 
                                  1, exception_qschema, 
                                  2, exception_qschema,  
                                  NULL) EXCEPTION_QUEUE_OWNER,  decode (state, 0, exception_queue, 
                                  1, exception_queue, 
                                  2, exception_queue,  
                                  NULL) EXCEPTION_QUEUE,  user_data,  decode (state, 3, 
                     decode (deq_tid, 'INVALID_TRANSACTION', NULL, 
                             exception_queue), NULL)
                                ORIGINAL_QUEUE_NAME,  decode (state, 3, 
                     decode (deq_tid, 'INVALID_TRANSACTION', NULL, 
                             exception_qschema), NULL)
                                ORIGINAL_QUEUE_OWNER,  decode(state, 3, 
                     decode(deq_time, NULL, 
                       decode(deq_tid, NULL,
                       decode (expiration , NULL , 'MAX_RETRY_EXCEEDED',
                            'TIME_EXPIRATION'),
                              'INVALID_TRANSACTION', NULL,
                              'MAX_RETRY_EXCEEDED'), NULL), NULL) 
                             EXPIRATION_REASON  FROM "DEF$_AQCALL" WHERE state != 7 AND   state != 9 WITH READ ONLY;

prompt
prompt Creating view AQ$DEF$_AQERROR
prompt =============================
prompt
CREATE OR REPLACE FORCE VIEW SYSTEM.AQ$DEF$_AQERROR AS
SELECT q_name QUEUE, msgid MSG_ID, corrid CORR_ID, priority MSG_PRIORITY, decode(state, 0,   'READY',
                                1,   'WAIT',
                                2,   'PROCESSED',
                                3,   'EXPIRED',
                                10,  'BUFFERED_EXPIRED') MSG_STATE, cast(FROM_TZ(delay, '-07:00')
                  at time zone sessiontimezone as date) DELAY, delay DELAY_TIMESTAMP, expiration, cast(FROM_TZ(enq_time, '-07:00')
                  at time zone sessiontimezone as date) ENQ_TIME, cast(FROM_TZ(enq_time, '-07:00')
                  at time zone sessiontimezone as timestamp) 
                  ENQ_TIMESTAMP, enq_uid ENQ_USER_ID, enq_tid ENQ_TXN_ID, cast(FROM_TZ(deq_time, '-07:00')
                  at time zone sessiontimezone as date) DEQ_TIME, cast(FROM_TZ(deq_time, '-07:00')
                  at time zone sessiontimezone as timestamp) 
                  DEQ_TIMESTAMP, deq_uid DEQ_USER_ID, deq_tid DEQ_TXN_ID, retry_count,  decode (state, 0, exception_qschema, 
                                  1, exception_qschema, 
                                  2, exception_qschema,  
                                  NULL) EXCEPTION_QUEUE_OWNER,  decode (state, 0, exception_queue, 
                                  1, exception_queue, 
                                  2, exception_queue,  
                                  NULL) EXCEPTION_QUEUE,  user_data,  decode (state, 3, 
                     decode (deq_tid, 'INVALID_TRANSACTION', NULL, 
                             exception_queue), NULL)
                                ORIGINAL_QUEUE_NAME,  decode (state, 3, 
                     decode (deq_tid, 'INVALID_TRANSACTION', NULL, 
                             exception_qschema), NULL)
                                ORIGINAL_QUEUE_OWNER,  decode(state, 3, 
                     decode(deq_time, NULL, 
                       decode(deq_tid, NULL,
                       decode (expiration , NULL , 'MAX_RETRY_EXCEEDED',
                            'TIME_EXPIRATION'),
                              'INVALID_TRANSACTION', NULL,
                              'MAX_RETRY_EXCEEDED'), NULL), NULL) 
                             EXPIRATION_REASON  FROM "DEF$_AQERROR" WHERE state != 7 AND   state != 9 WITH READ ONLY;

prompt
prompt Creating view AQ$_DEF$_AQCALL_F
prompt ===============================
prompt
CREATE OR REPLACE FORCE VIEW SYSTEM.AQ$_DEF$_AQCALL_F AS
SELECT qt.q_name Q_NAME, qt.rowid ROW_ID, qt.msgid MSGID, qt.corrid CORRID, qt.priority PRIORITY, qt.state STATE, qt.delay DELAY, qt.expiration EXPIRATION, qt.enq_time ENQ_TIME, qt.enq_uid ENQ_UID, qt.enq_tid ENQ_TID, qt.deq_time DEQ_TIME, qt.deq_uid DEQ_UID, qt.deq_tid DEQ_TID, qt.retry_count RETRY_COUNT, qt.exception_qschema EXCEPTION_QSCHEMA, qt.exception_queue EXCEPTION_QUEUE, qt.cscn CSCN, qt.dscn DSCN, qt.chain_no CHAIN_NO, qt.local_order_no LOCAL_ORDER_NO, qt.time_manager_info TIME_MANAGER_INFO, qt.step_no STEP_NO, qt.user_data USER_DATA  FROM "DEF$_AQCALL" qt, ALL_DEQUEUE_QUEUES qo  WHERE qt.q_name = qo.name WITH READ ONLY;

prompt
prompt Creating view AQ$_DEF$_AQERROR_F
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW SYSTEM.AQ$_DEF$_AQERROR_F AS
SELECT qt.q_name Q_NAME, qt.rowid ROW_ID, qt.msgid MSGID, qt.corrid CORRID, qt.priority PRIORITY, qt.state STATE, qt.delay DELAY, qt.expiration EXPIRATION, qt.enq_time ENQ_TIME, qt.enq_uid ENQ_UID, qt.enq_tid ENQ_TID, qt.deq_time DEQ_TIME, qt.deq_uid DEQ_UID, qt.deq_tid DEQ_TID, qt.retry_count RETRY_COUNT, qt.exception_qschema EXCEPTION_QSCHEMA, qt.exception_queue EXCEPTION_QUEUE, qt.cscn CSCN, qt.dscn DSCN, qt.chain_no CHAIN_NO, qt.local_order_no LOCAL_ORDER_NO, qt.time_manager_info TIME_MANAGER_INFO, qt.step_no STEP_NO, qt.user_data USER_DATA  FROM "DEF$_AQERROR" qt, ALL_DEQUEUE_QUEUES qo  WHERE qt.q_name = qo.name WITH READ ONLY;

prompt
prompt Creating view MVIEW_EVALUATIONS
prompt ===============================
prompt
create or replace force view system.mview_evaluations as
select
  t1.runid# as runid,
  summary_owner AS mview_owner,
  summary_name AS mview_name,
  rank# as rank,
  storage_in_bytes,
  frequency,
  cumulative_benefit,
  benefit_to_cost_ratio
from SYSTEM.MVIEW$_ADV_OUTPUT t1, SYSTEM.MVIEW$_ADV_LOG t2, ALL_USERS u
where
  t1.runid# = t2.runid# and
  u.username = t2.uname and
  u.user_id = userenv('SCHEMAID') and
  t1.output_type = 1
order by t1.rank#;
comment on table SYSTEM.MVIEW_EVALUATIONS is 'This view gives DBA access to summary evaluation output';

prompt
prompt Creating view MVIEW_EXCEPTIONS
prompt ==============================
prompt
create or replace force view system.mview_exceptions as
select
  t1.runid# as runid,
  owner,
  table_name,
  dimension_name,
  relationship,
  bad_rowid
from SYSTEM.MVIEW$_ADV_EXCEPTIONS t1, SYSTEM.MVIEW$_ADV_LOG t2, ALL_USERS u
where
  t1.runid# = t2.runid# and
  u.username = t2.uname and
  u.user_id = userenv('SCHEMAID');
comment on table SYSTEM.MVIEW_EXCEPTIONS is 'This view gives DBA access to dimension validation results';

prompt
prompt Creating view MVIEW_FILTER
prompt ==========================
prompt
create or replace force view system.mview_filter as
select
      a.filterid# as filterid,
      a.subfilternum# as subfilternum,
      decode(a.subfiltertype,1,'APPLICATION',2,'CARDINALITY',3,'LASTUSE',
                             4,'FREQUENCY',5,'USER',6,'PRIORITY',7,'BASETABLE',
                             8,'RESPONSETIME',9,'COLLECTIONID',10,'TRACENAME',
                             11,'SCHEMA','UNKNOWN') AS subfiltertype,
      a.str_value,
      to_number(decode(a.num_value1,-999,NULL,a.num_value1)) AS num_value1,
      to_number(decode(a.num_value2,-999,NULL,a.num_value2)) AS num_value2,
      a.date_value1,
      a.date_value2
   from system.mview$_adv_filter a, system.mview$_adv_log b, ALL_USERS u
   WHERE a.filterid# = b.runid#
   AND b.uname = u.username
   AND u.user_id = userenv('SCHEMAID');
comment on table SYSTEM.MVIEW_FILTER is 'Workload filter records';

prompt
prompt Creating view MVIEW_FILTERINSTANCE
prompt ==================================
prompt
create or replace force view system.mview_filterinstance as
select
      a.runid# as runid,
      a.filterid# as filterid,
      a.subfilternum# as subfilternum,
      decode(a.subfiltertype,1,'APPLICATION',2,'CARDINALITY',3,'LASTUSE',
                             4,'FREQUENCY',5,'USER',6,'PRIORITY',7,'BASETABLE',
                             8,'RESPONSETIME',9,'COLLECTIONID',10,'TRACENAME',
                             11,'SCHEMA','UNKNOWN') AS subfiltertype,
      a.str_value,
      to_number(decode(a.num_value1,-999,NULL,a.num_value1)) AS num_value1,
      to_number(decode(a.num_value2,-999,NULL,a.num_value2)) AS num_value2,
      a.date_value1,
      a.date_value2
   from system.mview$_adv_filterinstance a;
comment on table SYSTEM.MVIEW_FILTERINSTANCE is 'Workload filter instance records';

prompt
prompt Creating view MVIEW_LOG
prompt =======================
prompt
create or replace force view system.mview_log as
select
      m.runid# as id,
      m.filterid# as filterid,
      m.run_begin,
      m.run_end,
      decode(m.run_type,1,'EVALUATE',2,'EVALUATE_W',3,'RECOMMEND',
                      4,'RECOMMEND_W',5,'VALIDATE',6,'WORKLOAD',
                      7,'FILTER','UNKNOWN') AS type,
      decode(m.status,0,'UNUSED',1,'CANCELLED',2,'IN_PROGRESS',3,'COMPLETED',
                    4,'ERROR','UNKNOWN') AS status,
      m.message,
      m.completed,
      m.total,
      m.error_code
   from system.mview$_adv_log m, all_users u
   where m.uname = u.username
   and   u.user_id = userenv('SCHEMAID');
comment on table SYSTEM.MVIEW_LOG is 'Advisor session log';

prompt
prompt Creating view MVIEW_RECOMMENDATIONS
prompt ===================================
prompt
create or replace force view system.mview_recommendations as
select
  t1.runid# as runid,
  t1.from_clause as all_tables,
  fact_tables,
  grouping_levels,
  query_text,
  rank# as recommendation_number,
  action_type as recommended_action,
  summary_owner as mview_owner,
  summary_name as mview_name,
  storage_in_bytes,
  pct_performance_gain,
  benefit_to_cost_ratio
from SYSTEM.MVIEW$_ADV_OUTPUT t1, SYSTEM.MVIEW$_ADV_LOG t2, ALL_USERS u
where
  t1.runid# = t2.runid# and
  u.username = t2.uname and
  u.user_id = userenv('SCHEMAID') and
  t1.output_type = 0
order by t1.rank#;
comment on table SYSTEM.MVIEW_RECOMMENDATIONS is 'This view gives DBA access to summary recommendations';

prompt
prompt Creating view MVIEW_WORKLOAD
prompt ============================
prompt
create or replace force view system.mview_workload as
select
  a.collectionid# as workloadid,
  a.collecttime as import_time,
  a.queryid# as queryid,
  a.application,
  a.cardinality,
  a.resultsize,
  a.qdate as lastuse,
  a.frequency,
  a.uname as owner,
  a.priority,
  a.sql_text as query,
  a.exec_time as responsetime
from SYSTEM.MVIEW$_ADV_WORKLOAD A, SYSTEM.MVIEW$_ADV_LOG B, ALL_USERS D
WHERE a.collectionid# = b.runid#
AND b.uname = d.username
AND d.user_id = userenv('SCHEMAID');
comment on table SYSTEM.MVIEW_WORKLOAD is 'This view gives DBA access to shared workload';

prompt
prompt Creating view PRODUCT_PRIVS
prompt ===========================
prompt
CREATE OR REPLACE FORCE VIEW SYSTEM.PRODUCT_PRIVS AS
SELECT PRODUCT, USERID, ATTRIBUTE, SCOPE,
         NUMERIC_VALUE, CHAR_VALUE, DATE_VALUE, LONG_VALUE
  FROM SQLPLUS_PRODUCT_PROFILE
  WHERE USERID = 'PUBLIC' OR USER LIKE USERID;

prompt
prompt Creating package DBMS_REPCAT_AUTH
prompt =================================
prompt
CREATE OR REPLACE PACKAGE SYSTEM.dbms_repcat_auth wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
bf d6
0cfc6e4Sm6mfaMYwsbW2JygBepcwg/BKmJ4VZy/pO06UXsVUMejsissTcGWYR4qeK4TPqfDK
q7UPH+SmKP6nW9zmxMZnuK1VDzM0Iv9O4E4SvvsnHWn+EPF9hR+oBFe3fEro6RQ5R5Ejd1nr
e+fAK010dExf76gg/c6ZB3YxGPHDOqkGI4lV6HNsd57gKLwTd0bxan5UwJriIpt7Vjc=
/

prompt
prompt Creating type REPCAT$_OBJECT_NULL_VECTOR
prompt ========================================
prompt
CREATE OR REPLACE TYPE SYSTEM.repcat$_object_null_vector AS OBJECT
(
  -- type owner, name, hashcode for the type represented by null_vector
  type_owner      VARCHAR2(30),
  type_name       VARCHAR2(30),
  type_hashcode   RAW(17),
  -- null_vector for a particular object instance
  -- ROBJ REVISIT: should only contain the null image, and not version#
  null_vector     RAW(2000)
)
/

prompt
prompt Creating procedure ORA$_SYS_REP_AUTH
prompt ====================================
prompt
create or replace procedure system.ora$_sys_rep_auth as
begin
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.repcat$_repschema TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.repcat$_repprop TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_aqcall TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_calldest TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_error TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_destination TO SYS ' ||
                 'WITH GRANT OPTION';
end;
/

prompt
prompt Creating package body DBMS_REPCAT_AUTH
prompt ======================================
prompt
CREATE OR REPLACE PACKAGE BODY SYSTEM.dbms_repcat_auth wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
b50 380
xnRqD3/4A+337qNIT/E+IEanq9wwg5Urr0iDZy/NrQ9/GMX705drAKDlPWrgrt2eikWY3y7c
p68FZ5kEiMfjidC7MM2phG42L2anAgiKRxJOydQzI0e8OExGSri5yhzX6jjlnIYWmYwy3/vo
0dGmfdIaS7O9FKzv5oEKmsMiTlKpaFucasihmMZdnN9CvFcUxcTZkyzAckovEJE0ROLFqSkU
U1DLGtPTMHx9DqCFfTbWr0z7pZEU9luY0XgUjQ4sJK8pdMNBPI2lyJyf2c55K3oblN/EOHm0
WhEg7UCaowFu7mTmhmKDNw8CEc1ptBBrS3EFMmq6/QCalHY//sjWpRIWlFAgqMbtGRVTxUcB
w/NhShIl86i/5z0j5pr1qIDh+nECmD86nVGYPEjrTLmMGn1pRAkY0T1iw78Y5bGK8tQQAdMF
YcSfyyfLE1Kvamdr2NzM1SzaqWehtLTsD539TISJkDt/IDwDJsprAeaNrFgE/JFqVjVqxc2t
NUg5D90BHRwsCjpQTIbC9ZW8FUxW9IRS1ipwsQl0GTcK9ejP7HR+uYxL0N+yGtk+GOI3wWkt
N9TJgUuX0uTlMHsknK4ma6j8F0SWxVCD0N1rEiwKoq3JlOII8UIqQX1CoKia0AhiPvp9ZBws
O+g5Tk8/58b6fgAP2MvyAzn8h5b1qwF7P0R9ogE/A4/1kGz+W280j+LMjsYDHWsY0h4SxFm3
Q8xYXDj+ZNRlkBspIRLOppelIi48wXcnzvVx3JuI9JkVAx4ugRjjA97Czi8luOIDodNP99qj
xl6DJwGTe6Q7ghA8y5b5R+iNv7kmJP279CKvWSyAnV8l46s768QJfJp9sd8AyRL1OGEMOodZ
UReCJJE3mgMic1uTcDMu
/

prompt
prompt Creating trigger DEF$_PROPAGATOR_TRIG
prompt =====================================
prompt
CREATE OR REPLACE TRIGGER system.def$_propagator_trig
  BEFORE INSERT ON system.def$_propagator
DECLARE
  prop_count  NUMBER;
BEGIN
  SELECT count(*) into prop_count
    FROM system.def$_propagator;

  IF (prop_count > 0) THEN
    -- Raise duplicate propagator error
    sys.dbms_sys_error.raise_system_error(-23394);
  END IF;
END;
/

prompt
prompt Creating trigger REPCATLOGTRIG
prompt ==============================
prompt
CREATE OR REPLACE TRIGGER system.repcatlogtrig
AFTER UPDATE OR DELETE ON system.repcat$_repcatlog
BEGIN
  sys.dbms_alert.signal('repcatlog_alert', '');
END;
/


spool off
