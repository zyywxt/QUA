package zyy.wxt.pojo;

public class Student {
	private String stuNo;
	private String stuName;
	private String sex;
	private Integer age;
	private Integer id;
	private String clzss;
	public String getStuNo() {
		return stuNo;
	}
	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getClzss() {
		return clzss;
	}
	public void setClzss(String clzss) {
		this.clzss = clzss;
	}
	
    

}
